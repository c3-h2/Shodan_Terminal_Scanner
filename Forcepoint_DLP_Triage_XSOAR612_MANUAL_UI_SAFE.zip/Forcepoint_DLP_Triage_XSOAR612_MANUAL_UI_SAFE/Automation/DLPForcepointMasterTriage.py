
# This file is generated for Cortex XSOAR 6.12+ Python 3 automations.
# It intentionally uses only Python standard library + XSOAR CommonServerPython primitives.

import json
import re
import ipaddress
from typing import Any, Dict, List, Optional, Tuple

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    # Allows local syntax checks / unit tests outside XSOAR.
    pass


SEVERITY_NAME_TO_NUM = {
    "UNKNOWN": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def str_arg(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def bool_arg_local(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")


def normalize(value: Any) -> str:
    return str_arg(value).strip().lower()


def contains_ci(haystack: Any, needle: Any) -> bool:
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h


def contains_any_ci(haystack: Any, needles: List[str]) -> bool:
    h = normalize(haystack)
    return any(n.lower() in h for n in needles if n)


def split_rules(category: Any) -> List[str]:
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(";") if r.strip()]


def parse_json_arg(value: Any, default: Any) -> Any:
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def parse_csv(value: Any) -> List[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def extract_ips(value: Any) -> List[str]:
    text = str_arg(value)
    # IPv4 only is enough for Forcepoint dest strings in the source pseudo-code.
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)


def is_private_rfc1918(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False


def is_loopback_ip(ip_text: str) -> bool:
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False


def risk_to_num(risk_level: str) -> int:
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)


def get_xsoar_args() -> Dict[str, Any]:
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}


def return_xsoar_result(prefix: str, outputs: Dict[str, Any], readable: Optional[str] = None) -> None:
    try:
        readable_output = readable if readable is not None else tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable_output))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps(outputs, indent=2, ensure_ascii=False))

# Master orchestration automation for Forcepoint DLP 10.2 incidents in Cortex XSOAR 6.12+.
# It is intentionally self-contained so that a playbook can call only this automation.

COPILOT_WHITELIST = [
    "proxy.business.githubcopilot.com",
    "proxy.individual.githubcopilot.com",
    "api.githubcopilot.com",
    "api.github.com/chunks",
    "githubcopilot.com",
]

INTERNAL_DEV_SERVERS = [
    "10.200.107.112",
    "10.200.115.23",
]

APPROVED_DEST_WHITELIST = [
    {"entry": "transfer.kkb.com.tr", "category": "internal_transfer", "confidence": "HIGH"},
    {"entry": "j2.kkb.com.tr", "category": "internal_system", "confidence": "HIGH"},
    {"entry": "brainchat.kkb.com.tr", "category": "internal_system", "confidence": "HIGH"},
    {"entry": "z.clarity.ms", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "clarity.ms", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "trc.taboola.com", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "google-ohttp-relay-safebrowsing.fastly-edge.com", "category": "browser_security", "confidence": "HIGH"},
    {"entry": "safebrowsing.fastly-edge.com", "category": "browser_security", "confidence": "HIGH"},
    {"entry": "dlptest.endpointprotector.com", "category": "dlp_test_tool", "confidence": "HIGH"},
    {"entry": "www.ecurep.ibm.com", "category": "it_support_portal", "confidence": "MEDIUM"},
    {"entry": "ecurep.ibm.com", "category": "it_support_portal", "confidence": "MEDIUM"},
]

AI_TOOLS = [
    {"domain": "claude.ai", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.anthropic.com", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chat.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chatgpt.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "gemini.google.com", "name": "Gemini", "vendor": "Google"},
    {"domain": "copilot.microsoft.com", "name": "Copilot", "vendor": "Microsoft"},
    {"domain": "githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
    {"domain": "api.githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
    {"domain": "proxy.business.githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
    {"domain": "proxy.individual.githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
]

HIGH_RISK_KEYWORDS = [
    "credit card", "turkey protection of personal data", "kvkk",
    "db fingerprint", "yonetici onay", "yönetici onay", "mali isler", "mali işler",
    "musteri bilgisi", "müşteri bilgisi", "ftkw", "tckn", "iban",
]
MEDIUM_RISK_KEYWORDS = ["bulk data remover", "boldon james", "fingerprint"]
LOW_RISK_KEYWORDS = ["sifreli dosya", "şifreli dosya", "7zip encrypted", "video upload blocking", "test ai"]

FTP_CLIENT_PATTERNS = [
    "filezilla", "winscp", "file transfer program", "ftp client",
    "cute ftp", "core ftp", "smartftp", "ftpuse", "lftp",
]
FTP_RULE_KEYWORDS = ["ftp actions", "ftp action", "ftp transfer"]


def resolve_incident_field(incident: Dict[str, Any], explicit: Any, field_name: str) -> str:
    if explicit not in (None, ""):
        return str_arg(explicit)

    candidates = [
        field_name,
        field_name.lower(),
        field_name.replace("_", ""),
        field_name.replace(" ", ""),
        "dlpforcepoint{}".format(field_name.lower()),
        "forcepoint{}".format(field_name.lower()),
    ]

    # Top-level incident fields
    for key in candidates:
        if key in incident and incident.get(key) not in (None, ""):
            return str_arg(incident.get(key))

    # XSOAR custom fields may be under CustomFields or customFields
    for cf_key in ("CustomFields", "customFields"):
        custom_fields = incident.get(cf_key) or {}
        if isinstance(custom_fields, dict):
            for key in candidates:
                for actual_key, value in custom_fields.items():
                    if actual_key.lower() == key.lower() and value not in (None, ""):
                        return str_arg(value)

    # Labels fallback. Forcepoint integrations often map raw fields as labels before classifier/mapper tuning.
    labels = incident.get("labels") or incident.get("Labels") or []
    if isinstance(labels, list):
        for label in labels:
            if not isinstance(label, dict):
                continue
            label_type = str_arg(label.get("type") or label.get("Type")).lower()
            label_value = label.get("value") or label.get("Value")
            for key in candidates:
                if label_type == key.lower() and label_value not in (None, ""):
                    return str_arg(label_value)

    return ""


def add_label(label_type: str, label_value: str, dry_run: bool = False) -> List[Dict[str, Any]]:
    if dry_run:
        return []
    try:
        result = demisto.executeCommand("setIncident", {  # type: ignore[name-defined]
            "addLabels": json.dumps([{"type": label_type, "value": label_value}], ensure_ascii=False)
        })
        return result if isinstance(result, list) else []
    except Exception as ex:
        try:
            demisto.debug("DLP triage label update failed: {}".format(ex))  # type: ignore[name-defined]
        except Exception:
            pass
        return []


def set_incident_severity(severity_num: int, dry_run: bool = False) -> List[Dict[str, Any]]:
    if dry_run:
        return []
    try:
        result = demisto.executeCommand("setIncident", {"severity": severity_num})  # type: ignore[name-defined]
        return result if isinstance(result, list) else []
    except Exception as ex:
        try:
            demisto.debug("DLP triage severity update failed: {}".format(ex))  # type: ignore[name-defined]
        except Exception:
            pass
        return []


def close_incident_fp(close_notes: str, dry_run: bool = False) -> List[Dict[str, Any]]:
    if dry_run:
        return []
    try:
        result = demisto.executeCommand("closeInvestigation", {  # type: ignore[name-defined]
            "closeReason": "False Positive",
            "closeNotes": close_notes,
        })
        return result if isinstance(result, list) else []
    except Exception as ex:
        try:
            demisto.debug("DLP triage closeInvestigation failed: {}".format(ex))  # type: ignore[name-defined]
        except Exception:
            pass
        return []


def set_triage_labels(final_tag: str, action: str, reason: str, matched: Optional[str], dry_run: bool) -> None:
    add_label("dlp_triage_tag", final_tag, dry_run=dry_run)
    add_label("dlp_triage_action", action, dry_run=dry_run)
    add_label("dlp_triage_reason", reason[:1000], dry_run=dry_run)
    if matched:
        add_label("dlp_triage_matched", matched, dry_run=dry_run)


def check_copilot(dest: str, whitelist: List[str]) -> Dict[str, Any]:
    for entry in whitelist:
        if contains_ci(dest, entry):
            return {"is_fp": True, "confidence": "HIGH", "matched": entry, "category": "github_copilot", "reason": "GitHub Copilot destination matched."}
    return {"is_fp": False, "confidence": "NONE", "matched": None, "category": None, "reason": "No Copilot destination matched."}


def check_local(dest: str, servers: List[str]) -> Dict[str, Any]:
    d = normalize(dest)
    if any(x in d for x in ("localhost", "127.0.0.1", "::1")):
        return {"is_fp": True, "confidence": "HIGH", "matched": "loopback", "category": "loopback", "reason": "Destination is localhost/loopback."}
    ips = extract_ips(dest)
    for ip_text in ips:
        if is_loopback_ip(ip_text):
            return {"is_fp": True, "confidence": "HIGH", "matched": ip_text, "category": "loopback", "reason": "Destination IP is loopback."}
    for server in servers:
        if contains_ci(dest, server):
            return {"is_fp": True, "confidence": "HIGH", "matched": server, "category": "internal_dev_server", "reason": "Approved internal development server."}
    for ip_text in ips:
        if is_private_rfc1918(ip_text):
            return {"is_fp": True, "confidence": "MEDIUM", "matched": ip_text, "category": "rfc1918_private", "reason": "RFC1918 private destination; not auto-closed."}
    return {"is_fp": False, "confidence": "NONE", "matched": None, "category": None, "reason": "No local/internal destination matched."}


def normalize_approved(entries: Any) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    for item in entries or []:
        if isinstance(item, dict):
            entry = str_arg(item.get("entry"))
            category = str_arg(item.get("category"), "approved_destination")
            confidence = str_arg(item.get("confidence"), "HIGH").upper()
        elif isinstance(item, (list, tuple)) and len(item) >= 3:
            entry, category, confidence = str_arg(item[0]), str_arg(item[1]), str_arg(item[2]).upper()
        else:
            entry, category, confidence = str_arg(item), "approved_destination", "HIGH"
        if entry:
            normalized.append({"entry": entry, "category": category, "confidence": confidence})
    return normalized


def check_approved(dest: str, entries: List[Dict[str, str]]) -> Dict[str, Any]:
    for item in normalize_approved(entries):
        if contains_ci(dest, item["entry"]):
            return {"is_fp": True, "confidence": item["confidence"], "matched": item["entry"], "category": item["category"], "reason": "Approved destination matched."}
    return {"is_fp": False, "confidence": "NONE", "matched": None, "category": None, "reason": "No approved destination matched."}


def match_ai_tool(dest: str, tools: List[Dict[str, str]]) -> Optional[Dict[str, str]]:
    for tool in tools:
        if contains_ci(dest, tool.get("domain", "")):
            return tool
    return None


def keyword_match(rules: List[str], keywords: List[str]) -> Optional[str]:
    for rule in rules:
        for kw in keywords:
            if kw.lower() in rule:
                return kw
    return None


def check_ai(dest: str, category: str, tools: List[Dict[str, str]]) -> Dict[str, Any]:
    matched = match_ai_tool(dest, tools)
    rules = split_rules(category)
    if not matched:
        return {"is_ai_tool": False, "risk_level": None, "matched": None, "tool_name": None, "vendor": None, "reason": "Not AI destination.", "rules_parsed": rules}
    high_kw = keyword_match(rules, HIGH_RISK_KEYWORDS)
    if high_kw:
        return {"is_ai_tool": True, "risk_level": "HIGH", "matched": matched.get("domain"), "tool_name": matched.get("name"), "vendor": matched.get("vendor"), "reason": "High-risk AI rule keyword: {}".format(high_kw), "rules_parsed": rules}
    low_kw = keyword_match(rules, LOW_RISK_KEYWORDS)
    if low_kw:
        return {"is_ai_tool": True, "risk_level": "LOW", "matched": matched.get("domain"), "tool_name": matched.get("name"), "vendor": matched.get("vendor"), "reason": "Low-risk/test AI rule keyword: {}".format(low_kw), "rules_parsed": rules}
    med_kw = keyword_match(rules, MEDIUM_RISK_KEYWORDS)
    if med_kw:
        return {"is_ai_tool": True, "risk_level": "MEDIUM", "matched": matched.get("domain"), "tool_name": matched.get("name"), "vendor": matched.get("vendor"), "reason": "Medium-risk AI rule keyword: {}".format(med_kw), "rules_parsed": rules}
    return {"is_ai_tool": True, "risk_level": "MEDIUM", "matched": matched.get("domain"), "tool_name": matched.get("name"), "vendor": matched.get("vendor"), "reason": "Unknown AI rule; conservative medium risk.", "rules_parsed": rules}


def detect_bj_subtype(category: str) -> str:
    c = normalize(category)
    if "test" in c:
        return "test"
    if "yonetici onay" in c or "yönetici onay" in c:
        return "yonetici_onay"
    if "db fingerprint" in c:
        return "db_fingerprint"
    if "turkey" in c or "kvkk" in c or "kvk" in c:
        return "turkey_pd"
    if "musteri bilgisi" in c or "müşteri bilgisi" in c:
        return "musteri_bilgisi"
    if "bulk data" in c:
        return "bulk_data"
    if "fingerprint" in c:
        return "fingerprint"
    return "standard"


def classify_bj_dest(dest: str) -> str:
    d = normalize(dest)
    if contains_any_ci(d, ["gmail", "hotmail", "icloud", "windowslive", "outlook.com", "live.com", "yandex"]):
        return "personal_email"
    if "riskmerkezi" in d:
        return "authorized_partner"
    if "@kkb.com.tr" in d or ".kkb.com.tr" in d or d.endswith("kkb.com.tr"):
        return "internal"
    if d in ("smtp", "endpoint https") or "endpoint https" in d:
        return "generic_channel"
    return "corporate_external"


def check_bj(dest: str, category: str, is_ai_tool: bool) -> Dict[str, Any]:
    if is_ai_tool:
        return {"is_bj": "boldon james" in normalize(category), "skipped": True, "risk_level": None, "dest_type": None, "rule_subtype": None, "reason": "Skipped because AI triage already matched."}
    if "boldon james" not in normalize(category):
        return {"is_bj": False, "skipped": False, "risk_level": None, "dest_type": None, "rule_subtype": None, "reason": "Not a Boldon James rule."}
    subtype = detect_bj_subtype(category)
    dest_type = classify_bj_dest(dest)
    if subtype == "test":
        risk, reason = "LOW", "Boldon James test subtype."
    elif dest_type == "personal_email":
        risk, reason = "HIGH", "Personal email destination."
    elif subtype in ("yonetici_onay", "db_fingerprint", "turkey_pd", "musteri_bilgisi"):
        risk, reason = "HIGH", "Sensitive Boldon James subtype."
    elif dest_type == "authorized_partner":
        if subtype in ("fingerprint", "bulk_data"):
            risk, reason = "MEDIUM", "Authorized partner with fingerprint/bulk subtype."
        else:
            risk, reason = "LOW", "Authorized partner with standard subtype."
    elif dest_type == "internal":
        risk, reason = "LOW", "Internal destination."
    else:
        risk, reason = "MEDIUM", "External/generic destination with non-critical subtype."
    return {"is_bj": True, "skipped": False, "risk_level": risk, "dest_type": dest_type, "rule_subtype": subtype, "reason": reason}


def extract_size_kb(object_name: str) -> Optional[float]:
    m = re.search(r"-\s*([0-9]+(?:[.,][0-9]+)?)\s*(KB|MB|GB|B)\b", str_arg(object_name), re.IGNORECASE)
    if not m:
        return None
    value = float(m.group(1).replace(",", "."))
    unit = m.group(2).upper()
    if unit == "B":
        return value / 1024.0
    if unit == "KB":
        return value
    if unit == "MB":
        return value * 1024.0
    if unit == "GB":
        return value * 1024.0 * 1024.0
    return None


def basename(object_name: str) -> str:
    raw = str_arg(object_name).split(" - ")[0].replace("\\", "/")
    return raw.rsplit("/", 1)[-1]


def analyze_ftp_file(object_name: str) -> Dict[str, Any]:
    if not str_arg(object_name).strip():
        return {"file_risk_type": "unknown", "reason": "Object/file name is empty.", "size_kb": None}
    b = basename(object_name).lower()
    o = normalize(object_name)
    size_kb = extract_size_kb(object_name)
    if re.search(r"^(trv|rpt|exp|extract|report|data|export)[_-]\d{4,8}", b):
        return {"file_risk_type": "automated_export", "reason": "Date-prefixed export pattern.", "size_kb": size_kb}
    for kw in ["backup", "yedek", "full_backup", "dump"]:
        if kw in o:
            return {"file_risk_type": "backup", "reason": "Backup keyword: {}".format(kw), "size_kb": size_kb}
    for kw in ["fatura", "finance", "finansal", "banka", "bank", "musteri", "müşteri", "customer", "kart", "card", "kredi", "credit", "hesap", "account", "odeme", "ödeme", "payment", "swift", "iban", "tckn", "kvkk", "gizli", "confidential", "qsr", "salary", "maas", "maaş", "bordro", "payroll", "sozlesme", "sözleşme", "contract"]:
        if kw in o:
            return {"file_risk_type": "financial", "reason": "Sensitive keyword: {}".format(kw), "size_kb": size_kb}
    for prefix, max_size in {"den": 50, "test": 100, "deneme": 100, "sample": 100, "demo": 100}.items():
        if b.startswith(prefix) and (size_kb is None or size_kb <= max_size):
            return {"file_risk_type": "test_file", "reason": "Test prefix and small/unknown size.", "size_kb": size_kb}
    for kw in ["project", "method", "telco", "arsiv", "arşiv", "archive", "log", "config", "setup", "install"]:
        if kw in o:
            return {"file_risk_type": "dev_project", "reason": "Technical/dev keyword: {}".format(kw), "size_kb": size_kb}
    return {"file_risk_type": "unknown", "reason": "No FTP file pattern matched.", "size_kb": size_kb}


def check_ftp(dest: str, category: str, object_name: str) -> Dict[str, Any]:
    d, c = normalize(dest), normalize(category)
    ftp_client = next((p for p in FTP_CLIENT_PATTERNS if p in d), None)
    rule_match = next((kw for kw in FTP_RULE_KEYWORDS if kw in c), None)
    if not ftp_client and not rule_match:
        return {"is_ftp": False, "risk_level": None, "ftp_client": None, "file_risk_type": None, "reason": "No FTP indicator.", "server_note": None}
    file_analysis = analyze_ftp_file(object_name)
    risk = "HIGH" if file_analysis["file_risk_type"] in ("financial", "backup", "automated_export", "unknown") else "MEDIUM"
    return {"is_ftp": True, "risk_level": risk, "ftp_client": ftp_client, "file_risk_type": file_analysis["file_risk_type"], "reason": file_analysis["reason"], "size_kb": file_analysis.get("size_kb"), "server_note": "Forcepoint Endpoint DLP dest is FTP client name, not FTP server. Use pcap/proxy/network logs for real server."}


def triage(incident: Dict[str, Any], args: Dict[str, Any]) -> Dict[str, Any]:
    dest_field = str_arg(args.get("dest_field"), "dest")
    category_field = str_arg(args.get("category_field"), "category")
    app_field = str_arg(args.get("app_field"), "app")
    object_field = str_arg(args.get("object_field"), "object")

    dest = resolve_incident_field(incident, args.get("dest"), dest_field)
    category = resolve_incident_field(incident, args.get("category"), category_field)
    app = resolve_incident_field(incident, args.get("app"), app_field)
    object_name = resolve_incident_field(incident, args.get("object_name"), object_field)

    copilot_whitelist = parse_json_arg(args.get("copilot_whitelist_json"), COPILOT_WHITELIST)
    internal_servers = parse_csv(args.get("internal_dev_servers")) or INTERNAL_DEV_SERVERS
    approved_entries = parse_json_arg(args.get("approved_destinations_json"), APPROVED_DEST_WHITELIST)
    ai_tools = parse_json_arg(args.get("ai_tools_json"), AI_TOOLS)

    result: Dict[str, Any] = {
        "input": {"dest": dest, "category": category, "app": app, "object": object_name},
        "checks": [],
        "action": "none",
        "close": False,
        "close_reason": None,
        "severity": None,
        "severity_num": None,
        "tag": None,
        "reason": None,
        "matched": None,
        "manual_review_required": True,
    }

    handled = False
    final_severity_num = 0
    final_risk_name = None
    final_tag = None
    final_reason = None
    final_matched = None

    def set_risk(risk: str, tag: str, reason: str, matched: Optional[str] = None) -> None:
        nonlocal handled, final_severity_num, final_risk_name, final_tag, final_reason, final_matched
        handled = True
        sev_num = risk_to_num(risk)
        # Never lower a severity assigned by a more suspicious earlier/more specific branch.
        if sev_num >= final_severity_num:
            final_severity_num = sev_num
            final_risk_name = risk.upper()
            final_tag = tag
            final_reason = reason
            final_matched = matched

    cat_lower = normalize(category)

    # 1. GitHub Copilot autoclose scope: Software Source Code.
    if "software source code" in cat_lower:
        copilot = check_copilot(dest, copilot_whitelist)
        result["checks"].append({"name": "DLP_GithubCopilot_Autoclose", "result": copilot})
        if copilot["is_fp"]:
            result.update({
                "action": "auto_close",
                "close": True,
                "close_reason": "False Positive",
                "severity": "LOW",
                "severity_num": 1,
                "tag": "fp-github-copilot",
                "reason": "GitHub Copilot proxy/API traffic. Dest: {}".format(dest),
                "matched": copilot.get("matched"),
                "manual_review_required": False,
            })
            return result
        set_risk("HIGH", "ssc-manual-review", "Software Source Code rule did not match Copilot FP whitelist.", None)
    else:
        result["checks"].append({"name": "DLP_GithubCopilot_Autoclose", "result": {"skipped": True, "reason": "Category outside Software Source Code scope."}})

    # 2. Localhost/internal destination autoclose/low.
    if contains_any_ci(category, ["Software Source Code", "Boldon James", "Bulk Data Remover"]):
        local = check_local(dest, internal_servers)
        result["checks"].append({"name": "DLP_Localhost_Autoclose", "result": local})
        if local["is_fp"] and local["confidence"] == "HIGH":
            result.update({
                "action": "auto_close",
                "close": True,
                "close_reason": "False Positive",
                "severity": "LOW",
                "severity_num": 1,
                "tag": "fp-localhost",
                "reason": "Localhost/internal development destination. {}".format(local.get("reason")),
                "matched": local.get("matched"),
                "manual_review_required": False,
            })
            return result
        if local["is_fp"] and local["confidence"] == "MEDIUM":
            set_risk("LOW", "low-priority-internal", local.get("reason", "RFC1918 destination."), local.get("matched"))
    else:
        result["checks"].append({"name": "DLP_Localhost_Autoclose", "result": {"skipped": True, "reason": "Category outside Localhost scope."}})

    # 3. Approved destination.
    approved = check_approved(dest, approved_entries)
    result["checks"].append({"name": "DLP_ApprovedDest_Autoclose", "result": approved})
    if approved["is_fp"] and approved["confidence"] == "HIGH":
        result.update({
            "action": "auto_close",
            "close": True,
            "close_reason": "False Positive",
            "severity": "LOW",
            "severity_num": 1,
            "tag": "fp-approved-dest",
            "reason": "Approved destination: {} / {}".format(approved.get("matched"), approved.get("category")),
            "matched": approved.get("matched"),
            "manual_review_required": False,
        })
        return result
    if approved["is_fp"] and approved["confidence"] == "MEDIUM":
        set_risk("LOW", "low-priority-approved-dest", "Medium-confidence approved destination; analyst validation retained.", approved.get("matched"))

    # 4. AI tool triage.
    ai = check_ai(dest, category, ai_tools)
    result["checks"].append({"name": "DLP_AITool_Triage", "result": ai})
    if ai["is_ai_tool"]:
        if ai["risk_level"] == "HIGH":
            set_risk("HIGH", "ai-tool-high-risk", ai.get("reason", "AI tool high risk."), ai.get("matched"))
        elif ai["risk_level"] == "MEDIUM":
            set_risk("MEDIUM", "ai-tool-medium-risk", ai.get("reason", "AI tool medium risk."), ai.get("matched"))
        elif ai["risk_level"] == "LOW":
            set_risk("LOW", "ai-tool-fp-candidate", ai.get("reason", "AI tool low risk candidate."), ai.get("matched"))

    # 5. Boldon James triage, skipped when AI matched.
    bj = check_bj(dest, category, bool(ai.get("is_ai_tool")))
    result["checks"].append({"name": "DLP_BoldonJames_Triage", "result": bj})
    if bj.get("is_bj") and not bj.get("skipped"):
        if bj["risk_level"] == "HIGH":
            set_risk("HIGH", "bj-high-risk", bj.get("reason", "Boldon James high risk."), bj.get("dest_type"))
        elif bj["risk_level"] == "MEDIUM":
            set_risk("MEDIUM", "bj-medium-risk", bj.get("reason", "Boldon James medium risk."), bj.get("dest_type"))
        elif bj["risk_level"] == "LOW":
            set_risk("LOW", "bj-fp-candidate", bj.get("reason", "Boldon James low risk candidate."), bj.get("dest_type"))

    # 6. FTP triage. Never autoclose.
    ftp = check_ftp(dest, category, object_name)
    result["checks"].append({"name": "DLP_FTPAction_Triage", "result": ftp})
    if ftp.get("is_ftp"):
        if ftp["risk_level"] == "HIGH":
            set_risk("HIGH", "ftp-high-risk", "{} {}".format(ftp.get("reason"), ftp.get("server_note")), ftp.get("file_risk_type"))
        elif ftp["risk_level"] == "MEDIUM":
            set_risk("MEDIUM", "ftp-medium-risk", "{} {}".format(ftp.get("reason"), ftp.get("server_note")), ftp.get("file_risk_type"))

    if not handled:
        set_risk("MEDIUM", "manual-triage-required", "No DLP triage scope matched; routed to analyst queue.", None)

    result.update({
        "action": "set_severity",
        "close": False,
        "severity": final_risk_name,
        "severity_num": final_severity_num or 2,
        "tag": final_tag or "manual-triage-required",
        "reason": final_reason or "No final reason generated.",
        "matched": final_matched,
        "manual_review_required": True,
    })
    return result


def main() -> None:
    args = get_xsoar_args()
    dry_run = bool_arg_local(args.get("dry_run"), False)
    update_incident = bool_arg_local(args.get("update_incident"), True)
    close_incident = bool_arg_local(args.get("close_incident"), True)

    try:
        incident = demisto.incident()  # type: ignore[name-defined]
    except Exception:
        incident = {}

    result = triage(incident, args)

    if update_incident:
        if result.get("close") and close_incident:
            set_triage_labels(result["tag"], result["action"], result["reason"], result.get("matched"), dry_run)
            close_incident_fp(result["reason"], dry_run)
        else:
            set_incident_severity(int(result.get("severity_num") or 2), dry_run)
            set_triage_labels(result["tag"], result["action"], result["reason"], result.get("matched"), dry_run)

    readable = "### Forcepoint DLP Triage Result\n" + tableToMarkdown("Decision", {  # type: ignore[name-defined]
        "action": result.get("action"),
        "close": result.get("close"),
        "severity": result.get("severity"),
        "tag": result.get("tag"),
        "reason": result.get("reason"),
        "matched": result.get("matched"),
        "manual_review_required": result.get("manual_review_required"),
    }, removeNull=True) if "tableToMarkdown" in globals() else None

    return_xsoar_result("DLPForcepoint.Triage", result, readable)


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
