# Forcepoint DLP Triage — Manual UI Safe Package

Use this package when Cortex XSOAR 6.12 blocks unsigned content packs or fails YAML import.

Import method:

1. Do not import YAML.
2. Create one Python 3 automation manually.
3. Paste `Automation/DLPForcepointMasterTriage.py` into the script editor.
4. Add the arguments listed in `Docs/MANUAL_IMPORT_NO_YAML.md`.
5. Create a one-task playbook manually.

Primary file:

- `Automation/DLPForcepointMasterTriage.py`

Guide:

- `Docs/MANUAL_IMPORT_NO_YAML.md`
