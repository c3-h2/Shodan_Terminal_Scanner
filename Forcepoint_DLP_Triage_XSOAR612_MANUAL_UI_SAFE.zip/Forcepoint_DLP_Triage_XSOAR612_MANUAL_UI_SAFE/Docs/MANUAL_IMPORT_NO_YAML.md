# Forcepoint DLP Triage — XSOAR 6.12 Manual UI Import Guide

Bu paket özellikle `yml import` ve `msgpack: invalid code=c3 decoding string/bytes length` hatasına takılan XSOAR 6.12 ortamları için hazırlanmıştır.

Bu yöntemde hiçbir YAML dosyası import edilmez. Sadece Python kodu yeni bir Automation içine kopyalanır ve playbook UI üzerinden elle oluşturulur.

## 1. Automation oluştur

1. XSOAR UI: **Settings → Automation & Feed Integrations → Automation Scripts** veya **Automations** ekranına git.
2. **New Script** seç.
3. Aşağıdaki alanları gir:

| Alan | Değer |
|---|---|
| Name | `DLPForcepointMasterTriage` |
| Language | `Python 3` |
| Description | `Forcepoint DLP 10.2 alarm triage automation` |
| Run on | `Server` |
| Docker image | Varsayılan Python 3 / `demisto/python3` |
| Tags | `forcepoint`, `dlp`, `triage` |

4. `Automation/DLPForcepointMasterTriage.py` dosyasındaki tüm kodu script editor içine kopyala.
5. Save.

## 2. Automation argümanlarını ekle

Automation ayarlarında aşağıdaki argümanları ekle. Required alanını hiçbirinde işaretleme.

| Argument | Type | Default | Açıklama |
|---|---|---:|---|
| `dest` | String |  | Manuel test / override destination |
| `category` | String |  | Manuel test / override DLP rule category |
| `app` | String |  | Manuel test / override application |
| `object_name` | String |  | Manuel test / override file/object |
| `dest_field` | String | `dest` | Incident destination field name |
| `category_field` | String | `category` | Incident category/rule field name |
| `app_field` | String | `app` | Incident application field name |
| `object_field` | String | `object` | Incident object/file field name |
| `dry_run` | Boolean | `true` | Test modunda incident güncellemez/kapatmaz |
| `update_incident` | Boolean | `false` | Incident severity/label güncellemesini açar |
| `close_incident` | Boolean | `false` | Güvenli FP auto-close davranışını açar |
| `internal_dev_servers` | String |  | Virgülle ayrılmış iç dev server IP listesi |
| `copilot_whitelist_json` | String |  | JSON whitelist override |
| `approved_destinations_json` | String |  | JSON approved destination override |
| `ai_tools_json` | String |  | JSON AI tool override |

> İlk canlı testte `dry_run=true`, `update_incident=false`, `close_incident=false` kullan.

## 3. War Room testleri

### AI yüksek risk testi

```text
!DLPForcepointMasterTriage dry_run=true dest="chatgpt.com" category="KVKK; Credit Card" object_name="customer_data.xlsx - 4 MB"
```

Beklenen:

```text
action=set_severity
severity=HIGH
tag=ai-tool-high-risk
manual_review_required=true
```

### GitHub Copilot false-positive testi

```text
!DLPForcepointMasterTriage dry_run=true dest="proxy.business.githubcopilot.com" category="Software Source Code" object_name="source.py"
```

Beklenen:

```text
action=close_fp
close=true
tag=fp-github-copilot
```

### FTP yüksek risk testi

```text
!DLPForcepointMasterTriage dry_run=true dest="FileZilla FTP Client" category="FTP ACTIONS" object_name="backup_customer_data.zip - 20 MB"
```

Beklenen:

```text
action=set_severity
severity=HIGH
tag=ftp-high-risk
manual_review_required=true
```

## 4. Playbook'u elle oluştur

1. **Playbooks → New Playbook**.
2. Name: `DLP_Master_Triage`.
3. Tek bir automation task ekle:
   - Task name: `Run Forcepoint DLP Master Triage`
   - Automation: `DLPForcepointMasterTriage`
4. Task argümanları:

| Argument | İlk pilot değer |
|---|---|
| `dest_field` | `dest` |
| `category_field` | `category` |
| `app_field` | `app` |
| `object_field` | `object` |
| `dry_run` | `false` |
| `update_incident` | `true` |
| `close_incident` | `false` |

5. Playbook'u Forcepoint DLP incident type'a bağla.

## 5. Auto-close'u açma sırası

Önerilen pilot sırası:

1. War Room dry-run testleri.
2. Incident type üzerinde `close_incident=false` ile canlı pilot.
3. 1-2 hafta FP kararlarını gözlemle.
4. Sadece Copilot, localhost ve high-confidence approved destination sonuçları doğruysa `close_incident=true` yap.

## 6. Neden YAML import kullanmıyoruz?

Bu yöntem XSOAR'un farklı import ekranlarının farklı dosya formatı beklemesinden kaynaklanan hataları bypass eder. Automation kodu UI üzerinden doğrudan oluşturulduğu için pack imzası, unified YAML, source YAML ve msgpack decode sorunları devre dışı kalır.
