from CommonServerPython import *  # noqa: F401,F403
from CommonServerUserPython import *  # noqa: F401,F403

import ipaddress
from typing import Any, Dict, List, Optional, Tuple

import requests
from requests.auth import HTTPBasicAuth


DEFAULT_IP_FIELDS = (
    'ip_address,status,usage,types,names,mac_address,network,network_view,'
    'lease_state,is_conflict,objects,comment'
)
DEFAULT_NETWORK_FIELDS = 'network,network_view,comment,utilization,utilization_update,extattrs'


class Client(BaseClient):
    def __init__(self, base_url: str, username: str, password: str, verify: bool, proxy: bool,
                 page_size: int = 500, timeout: int = 60):
        super().__init__(base_url=base_url, verify=verify, proxy=proxy)
        self.auth = HTTPBasicAuth(username, password)
        self.page_size = page_size
        self.timeout = timeout

    def request(self, resource: str, params: Optional[Dict[str, Any]] = None) -> Any:
        url = f'{self._base_url}/{resource.lstrip("/")}'
        try:
            response = requests.get(
                url,
                params=params or {},
                auth=self.auth,
                verify=self._verify,
                proxies=self._proxies,
                timeout=self.timeout,
                headers={'Accept': 'application/json'},
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as exc:
            body = exc.response.text if exc.response is not None else str(exc)
            raise DemistoException(f'Infoblox WAPI HTTP error: {body}') from exc
        except requests.exceptions.RequestException as exc:
            raise DemistoException(f'Infoblox WAPI connection error: {exc}') from exc
        except ValueError as exc:
            raise DemistoException('Infoblox WAPI returned a non-JSON response.') from exc

    def paged_get(self, resource: str, query: Optional[Dict[str, Any]], max_records: int) -> Tuple[List[Dict[str, Any]], bool]:
        params = dict(query or {})
        params.update({'_paging': 1, '_return_as_object': 1, '_max_results': self.page_size})
        records: List[Dict[str, Any]] = []
        truncated = False
        page_id = None

        while True:
            if page_id:
                params['_page_id'] = page_id
            result = self.request(resource, params)
            page = result.get('result', []) if isinstance(result, dict) else result
            if not isinstance(page, list):
                raise DemistoException('Unexpected Infoblox paging response structure.')

            remaining = max_records - len(records)
            if remaining <= 0:
                truncated = True
                break
            records.extend(page[:remaining])
            if len(page) > remaining:
                truncated = True
                break

            page_id = result.get('next_page_id') if isinstance(result, dict) else None
            if not page_id:
                break
            if len(records) >= max_records:
                truncated = True
                break

        return records, truncated


def normalize_url(server: str, wapi_version: str) -> str:
    server = server.rstrip('/')
    if '/wapi/' in server:
        return server
    return f'{server}/wapi/v{wapi_version.strip().lstrip("v")}'


def parse_csv(value: Optional[str]) -> List[str]:
    return [item.strip() for item in (value or '').split(',') if item.strip()]


def is_used(record: Dict[str, Any]) -> bool:
    status = str(record.get('status', '')).upper()
    lease_state = str(record.get('lease_state', '')).upper()
    usage = record.get('usage') or []
    types = record.get('types') or []
    names = record.get('names') or []
    mac = str(record.get('mac_address') or '').strip()
    objects = record.get('objects') or []

    unused_statuses = {'UNUSED', 'AVAILABLE', 'FREE'}
    inactive_leases = {'', 'FREE', 'EXPIRED', 'RELEASED', 'BACKUP'}
    if status and status not in unused_statuses:
        return True
    if lease_state not in inactive_leases:
        return True
    return bool(usage or types or names or mac or objects)


def classify(record: Dict[str, Any]) -> str:
    if record.get('is_conflict'):
        return 'CONFLICT'
    lease_state = str(record.get('lease_state', '')).upper()
    types = {str(v).upper() for v in (record.get('types') or [])}
    usage = {str(v).upper() for v in (record.get('usage') or [])}
    status = str(record.get('status', '')).upper()
    if lease_state and lease_state not in {'FREE', 'EXPIRED', 'RELEASED', 'BACKUP'}:
        return 'ACTIVE_DHCP'
    if any('FIXED' in item for item in types):
        return 'FIXED_ADDRESS'
    if any('HOST' in item for item in types):
        return 'HOST_RECORD'
    if 'DNS' in usage or record.get('names'):
        return 'DNS_CONFIGURED'
    if status in {'RESERVED'} or any('RESERV' in item for item in types):
        return 'RESERVED'
    if is_used(record):
        return 'USED_OTHER'
    return 'UNUSED'


def enrich(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    output = []
    for item in records:
        row = dict(item)
        row['classification'] = classify(row)
        row['is_used'] = is_used(row)
        output.append(row)
    return output


def get_ip_command(client: Client, args: Dict[str, Any]) -> CommandResults:
    ip = args.get('ip')
    try:
        ipaddress.ip_address(ip)
    except ValueError as exc:
        raise DemistoException(f'Invalid IP address: {ip}') from exc
    params = {'ip_address': ip, '_return_fields': args.get('return_fields') or DEFAULT_IP_FIELDS}
    if args.get('network_view'):
        params['network_view'] = args['network_view']
    records = enrich(client.request('ipv4address', params))
    return CommandResults(
        readable_output=tableToMarkdown(f'Infoblox IPAM result for {ip}', records, removeNull=True),
        outputs_prefix='InfobloxIPAM.IP',
        outputs_key_field=['ip_address', 'network_view'],
        outputs=records,
        raw_response=records,
    )


def list_subnet_ips_command(client: Client, args: Dict[str, Any]) -> CommandResults:
    network = args.get('network')
    try:
        ipaddress.ip_network(network, strict=False)
    except ValueError as exc:
        raise DemistoException(f'Invalid CIDR network: {network}') from exc
    max_records = arg_to_number(args.get('max_records')) or 10000
    params = {'network': network, '_return_fields': args.get('return_fields') or DEFAULT_IP_FIELDS}
    if args.get('network_view'):
        params['network_view'] = args['network_view']
    records, truncated = client.paged_get('ipv4address', params, max_records)
    records = enrich(records)
    if argToBoolean(args.get('used_only', True)):
        records = [r for r in records if r['is_used']]
    summary = {'network': network, 'returned': len(records), 'truncated': truncated}
    return CommandResults(
        readable_output=tableToMarkdown(f'Infoblox IP addresses in {network}', records, removeNull=True),
        outputs_prefix='InfobloxIPAM.IP',
        outputs_key_field=['ip_address', 'network_view'],
        outputs=records,
        raw_response={'summary': summary, 'records': records},
    )


def list_networks_command(client: Client, args: Dict[str, Any]) -> CommandResults:
    max_records = arg_to_number(args.get('max_records')) or 10000
    params = {'_return_fields': args.get('return_fields') or DEFAULT_NETWORK_FIELDS}
    if args.get('network_view'):
        params['network_view'] = args['network_view']
    records, truncated = client.paged_get('network', params, max_records)
    return CommandResults(
        readable_output=tableToMarkdown('Infoblox IPAM networks', records, removeNull=True),
        outputs_prefix='InfobloxIPAM.Network',
        outputs_key_field=['network', 'network_view'],
        outputs=records,
        raw_response={'truncated': truncated, 'records': records},
    )


def list_all_used_ips_command(client: Client, args: Dict[str, Any]) -> CommandResults:
    max_records = arg_to_number(args.get('max_records')) or 50000
    params = {'_return_fields': args.get('return_fields') or DEFAULT_IP_FIELDS}
    if args.get('network_view'):
        params['network_view'] = args['network_view']
    statuses = parse_csv(args.get('status'))
    if len(statuses) == 1:
        params['status'] = statuses[0]
    records, truncated = client.paged_get('ipv4address', params, max_records)
    records = enrich(records)
    if statuses:
        wanted = {s.upper() for s in statuses}
        records = [r for r in records if str(r.get('status', '')).upper() in wanted]
    if argToBoolean(args.get('used_only', True)):
        records = [r for r in records if r['is_used']]
    summary = {'returned': len(records), 'truncated': truncated, 'max_records': max_records}
    readable = tableToMarkdown('Infoblox IPAM used IP addresses', records, removeNull=True)
    readable += '\n\n' + tableToMarkdown('Collection summary', summary)
    return CommandResults(
        readable_output=readable,
        outputs_prefix='InfobloxIPAM.IP',
        outputs_key_field=['ip_address', 'network_view'],
        outputs=records,
        raw_response={'summary': summary, 'records': records},
    )


def test_module(client: Client) -> str:
    result = client.request('networkview', {'_max_results': 1, '_return_fields': 'name,is_default'})
    if not isinstance(result, list):
        raise DemistoException('Unexpected response while testing Infoblox WAPI.')
    return 'ok'


def main() -> None:
    params = demisto.params()
    base_url = normalize_url(params.get('url', ''), params.get('wapi_version', '2.13.7'))
    client = Client(
        base_url=base_url,
        username=params.get('credentials', {}).get('identifier', ''),
        password=params.get('credentials', {}).get('password', ''),
        verify=not params.get('insecure', False),
        proxy=params.get('proxy', False),
        page_size=int(params.get('page_size', 500)),
        timeout=int(params.get('timeout', 60)),
    )
    command = demisto.command()
    try:
        if command == 'test-module':
            return_results(test_module(client))
        elif command == 'infoblox-ipam-get-ip':
            return_results(get_ip_command(client, demisto.args()))
        elif command == 'infoblox-ipam-list-subnet-ips':
            return_results(list_subnet_ips_command(client, demisto.args()))
        elif command == 'infoblox-ipam-list-networks':
            return_results(list_networks_command(client, demisto.args()))
        elif command == 'infoblox-ipam-list-all-used-ips':
            return_results(list_all_used_ips_command(client, demisto.args()))
        else:
            raise NotImplementedError(f'Command not implemented: {command}')
    except Exception as exc:
        return_error(f'Failed to execute {command}. Error: {exc}')


if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
