# Infoblox IPAM – Cortex XSOAR 6.14

Bu paket Infoblox WAPI üzerinden ağları ve IPv4 adreslerini sorgular. WAPI pagination otomatik uygulanır.

## XSOAR 6.14 doğrudan kurulum

1. `Integrations/InfobloxIPAM/InfobloxIPAM.yml` dosyasını indirin.
2. XSOAR: **Settings → Integrations → Servers & Services → Upload Integration**.
3. YAML dosyasını yükleyin.
4. Yeni bir instance oluşturun ve aşağıdaki alanları girin:
   - Server URL: `https://infoblox.example.com`
   - Username / Password
   - WAPI Version: Infoblox sisteminizin desteklediği sürüm; varsayılan `2.13.7`
   - Page Size: varsayılan `500`
5. **Test** düğmesine basın.

> Unsigned content pack yükleme kısıtı bulunan XSOAR 6.14 ortamlarında ZIP paket yerine doğrudan integration YAML yükleyin.

## Komutlar

### Belirli IP sorgulama

```text
!infoblox-ipam-get-ip ip="10.10.10.25" network_view="default"
```

### Subnet içindeki kullanılan IP'ler

```text
!infoblox-ipam-list-subnet-ips network="10.10.10.0/24" network_view="default" used_only="true" max_records="10000"
```

### Tüm subnetleri listeleme

```text
!infoblox-ipam-list-networks network_view="default" max_records="10000"
```

### Tüm erişilebilir subnetlerde kullanılan IP'leri toplama

```text
!infoblox-ipam-list-all-used-ips network_view="default" used_only="true" max_records="50000"
```

Birden fazla Network View sorgulanacaksa `network_view` parametresini boş bırakın. Sonuçlar `InfobloxIPAM.IP` ve `InfobloxIPAM.Network` context yollarına yazılır.

## Kullanım kararı

Entegrasyon bir adresi aşağıdakilerden biri mevcutsa kullanılan olarak sınıflandırır:

- Infoblox status değeri boş/kullanılabilir durumdan farklıysa
- Aktif DHCP lease varsa
- DNS/DHCP usage, associated object type, DNS name, MAC veya related object bulunuyorsa

`classification` alanı `ACTIVE_DHCP`, `FIXED_ADDRESS`, `HOST_RECORD`, `DNS_CONFIGURED`, `RESERVED`, `CONFLICT`, `USED_OTHER` veya `UNUSED` değerlerinden birini üretir.

## Operasyonel not

`max_records` güvenlik sınırıdır. Çok büyük ortamlarda değeri kontrollü artırın. API hesabının ilgili Network View, network, DHCP, DNS ve discovery verileri üzerinde okuma yetkisi bulunmalıdır.
