# Forcepoint DLP Triage — XSOAR 6.12 Import Guide

Bu paket iki farklı import yöntemi destekler.

## Önerilen yöntem: tek tek custom content import

Kurumsal policy unsigned content pack import etmeye izin vermiyorsa en güvenli yöntem budur. Marketplace pack olarak değil, custom automation + playbook olarak import edilir.

1. XSOAR UI üzerinden API key oluşturun.
2. Paketi XSOAR sunucusuna veya erişebilen bir yönetim makinesine açın.
3. Aşağıdaki scriptlerden birini çalıştırın:

Linux/macOS:

```bash
cd Deployment
export XSOAR_URL="https://xsoar.example.local"
export XSOAR_API_KEY="<api-key>"
./upload_unified_items.sh
```

Windows PowerShell 7+:

```powershell
cd Deployment
.\upload_unified_items.ps1 -XsoarUrl "https://xsoar.example.local" -ApiKey "<api-key>"
```

Bu yöntem şu endpointleri kullanır:

- `/automation/import`
- `/playbook/save/yaml`

## Alternatif yöntem: pack upload + skipVerify

Sadece kurum policy’si özel/dev pack için izin veriyorsa kullanılmalı.

Linux/macOS:

```bash
cd Deployment
export XSOAR_URL="https://xsoar.example.local"
export XSOAR_API_KEY="<api-key>"
./upload_pack_skip_verify.sh ../ForcepointDLPTriage_pack_with_Packs_root.zip
```

Windows PowerShell 7+:

```powershell
cd Deployment
.\upload_pack_skip_verify.ps1 -XsoarUrl "https://xsoar.example.local" -ApiKey "<api-key>" -PackFile "..\ForcepointDLPTriage_pack_with_Packs_root.zip"
```

Bu yöntem `/contentpacks/installed/upload` endpointini `skipVerify=true` ile çağırır.

## Manuel UI yöntemi

UI’da tekil import destekleniyorsa:

1. `UnifiedYAML/automation-*.yml` dosyalarını Automation import ekranından içeri alın.
2. `UnifiedYAML/playbook-DLP_Master_Triage.yml` dosyasını Playbook import ekranından içeri alın.
3. Playbook’u Forcepoint DLP incident type’a bağlamadan önce `dry_run=true` ile test edin.

## Canlıya alma sırası

1. Önce `DLPForcepointMasterTriage` automation’ını War Room’da test edin:

```text
!DLPForcepointMasterTriage dry_run=true dest="chatgpt.com" category="KVKK; Credit Card" object_name="customer_data.xlsx - 4 MB"
```

2. İlk pilotta playbook task argümanlarını şöyle ayarlayın:

```text
dry_run=false
update_incident=true
close_incident=false
```

3. 1-2 hafta sonuçları gözlemledikten sonra sadece yüksek güven FP auto-close için:

```text
close_incident=true
```

## Notlar

- `UnifiedYAML` klasöründeki automation dosyaları Python kodunu YAML içine gömülü taşır. Bu nedenle tekil automation import için uygundur.
- `Packs/ForcepointDLPTriage` klasörü demisto-sdk / CI-CD akışı için kaynak yapıdır.
- `ForcepointDLPTriage_pack_with_Packs_root.zip` ve `ForcepointDLPTriage_pack_root_only.zip` iki farklı XSOAR pack upload varyantı için hazırlandı. Çoğu CI/CD senaryosunda `with_Packs_root` tercih edilir.
