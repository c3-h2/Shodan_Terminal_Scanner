
# This file is generated for Cortex XSOAR 6.12+ Python 3 automations.
# It intentionally uses only Python standard library + XSOAR CommonServerPython primitives.

import json
import re
import ipaddress
from typing import Any, Dict, List, Optional, Tuple

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    # Allows local syntax checks / unit tests outside XSOAR.
    pass


SEVERITY_NAME_TO_NUM = {
    "UNKNOWN": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def str_arg(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def bool_arg_local(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")


def normalize(value: Any) -> str:
    return str_arg(value).strip().lower()


def contains_ci(haystack: Any, needle: Any) -> bool:
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h


def contains_any_ci(haystack: Any, needles: List[str]) -> bool:
    h = normalize(haystack)
    return any(n.lower() in h for n in needles if n)


def split_rules(category: Any) -> List[str]:
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(";") if r.strip()]


def parse_json_arg(value: Any, default: Any) -> Any:
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def parse_csv(value: Any) -> List[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def extract_ips(value: Any) -> List[str]:
    text = str_arg(value)
    # IPv4 only is enough for Forcepoint dest strings in the source pseudo-code.
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)


def is_private_rfc1918(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False


def is_loopback_ip(ip_text: str) -> bool:
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False


def risk_to_num(risk_level: str) -> int:
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)


def get_xsoar_args() -> Dict[str, Any]:
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}


def return_xsoar_result(prefix: str, outputs: Dict[str, Any], readable: Optional[str] = None) -> None:
    try:
        readable_output = readable if readable is not None else tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable_output))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps(outputs, indent=2, ensure_ascii=False))

DEFAULT_INTERNAL_DEV_SERVERS = [
    "10.200.107.112",
    "10.200.115.23",
]


def check_dest(dest: str, internal_dev_servers: Optional[List[str]] = None) -> Dict[str, Any]:
    internal_dev_servers = internal_dev_servers or DEFAULT_INTERNAL_DEV_SERVERS
    dest_norm = normalize(dest)

    if any(x in dest_norm for x in ("localhost", "127.0.0.1", "::1")):
        return {
            "is_fp": True,
            "confidence": "HIGH",
            "matched": "loopback",
            "category": "loopback",
            "reason": "Destination is loopback/localhost.",
        }

    ips = extract_ips(dest)
    for ip_text in ips:
        if is_loopback_ip(ip_text):
            return {
                "is_fp": True,
                "confidence": "HIGH",
                "matched": ip_text,
                "category": "loopback",
                "reason": "Destination IP is loopback.",
            }

    for server in internal_dev_servers:
        if contains_ci(dest, server):
            return {
                "is_fp": True,
                "confidence": "HIGH",
                "matched": server,
                "category": "internal_dev_server",
                "reason": "Destination matched approved internal development server.",
            }

    for ip_text in ips:
        if is_private_rfc1918(ip_text):
            return {
                "is_fp": True,
                "confidence": "MEDIUM",
                "matched": ip_text,
                "category": "rfc1918_private",
                "reason": "Destination matched RFC1918 private IP. Not auto-closed by design.",
            }

    return {"is_fp": False, "confidence": "NONE", "matched": None, "category": None, "reason": "No localhost/internal destination matched."}


def main() -> None:
    args = get_xsoar_args()
    dest = str_arg(args.get("dest"))
    servers = parse_csv(args.get("internal_dev_servers")) or DEFAULT_INTERNAL_DEV_SERVERS
    result = check_dest(dest, servers)
    return_xsoar_result("DLPLocalDestCheck", result)


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
