
# This file is generated for Cortex XSOAR 6.12+ Python 3 automations.
# It intentionally uses only Python standard library + XSOAR CommonServerPython primitives.

import json
import re
import ipaddress
from typing import Any, Dict, List, Optional, Tuple

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    # Allows local syntax checks / unit tests outside XSOAR.
    pass


SEVERITY_NAME_TO_NUM = {
    "UNKNOWN": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def str_arg(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def bool_arg_local(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")


def normalize(value: Any) -> str:
    return str_arg(value).strip().lower()


def contains_ci(haystack: Any, needle: Any) -> bool:
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h


def contains_any_ci(haystack: Any, needles: List[str]) -> bool:
    h = normalize(haystack)
    return any(n.lower() in h for n in needles if n)


def split_rules(category: Any) -> List[str]:
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(";") if r.strip()]


def parse_json_arg(value: Any, default: Any) -> Any:
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def parse_csv(value: Any) -> List[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def extract_ips(value: Any) -> List[str]:
    text = str_arg(value)
    # IPv4 only is enough for Forcepoint dest strings in the source pseudo-code.
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)


def is_private_rfc1918(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False


def is_loopback_ip(ip_text: str) -> bool:
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False


def risk_to_num(risk_level: str) -> int:
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)


def get_xsoar_args() -> Dict[str, Any]:
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}


def return_xsoar_result(prefix: str, outputs: Dict[str, Any], readable: Optional[str] = None) -> None:
    try:
        readable_output = readable if readable is not None else tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable_output))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps(outputs, indent=2, ensure_ascii=False))

DEFAULT_APPROVED_DEST_WHITELIST = [
    {"entry": "transfer.kkb.com.tr", "category": "internal_transfer", "confidence": "HIGH"},
    {"entry": "j2.kkb.com.tr", "category": "internal_system", "confidence": "HIGH"},
    {"entry": "brainchat.kkb.com.tr", "category": "internal_system", "confidence": "HIGH"},
    {"entry": "z.clarity.ms", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "clarity.ms", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "trc.taboola.com", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "google-ohttp-relay-safebrowsing.fastly-edge.com", "category": "browser_security", "confidence": "HIGH"},
    {"entry": "safebrowsing.fastly-edge.com", "category": "browser_security", "confidence": "HIGH"},
    {"entry": "dlptest.endpointprotector.com", "category": "dlp_test_tool", "confidence": "HIGH"},
    {"entry": "www.ecurep.ibm.com", "category": "it_support_portal", "confidence": "MEDIUM"},
    {"entry": "ecurep.ibm.com", "category": "it_support_portal", "confidence": "MEDIUM"},
]


def _normalize_entries(entries: Any) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    for item in entries or []:
        if isinstance(item, dict):
            entry = str_arg(item.get("entry"))
            category = str_arg(item.get("category"), "approved_destination")
            confidence = str_arg(item.get("confidence"), "HIGH").upper()
        elif isinstance(item, (list, tuple)) and len(item) >= 3:
            entry, category, confidence = str_arg(item[0]), str_arg(item[1]), str_arg(item[2]).upper()
        else:
            entry, category, confidence = str_arg(item), "approved_destination", "HIGH"
        if entry:
            normalized.append({"entry": entry, "category": category, "confidence": confidence})
    return normalized


def check_dest(dest: str, approved_entries: Optional[List[Dict[str, str]]] = None) -> Dict[str, Any]:
    entries = _normalize_entries(approved_entries or DEFAULT_APPROVED_DEST_WHITELIST)
    for item in entries:
        if contains_ci(dest, item["entry"]):
            return {
                "is_fp": True,
                "confidence": item["confidence"],
                "matched": item["entry"],
                "category": item["category"],
                "reason": "Destination matched approved destination list.",
            }
    return {"is_fp": False, "confidence": "NONE", "matched": None, "category": None, "reason": "No approved destination matched."}


def main() -> None:
    args = get_xsoar_args()
    dest = str_arg(args.get("dest"))
    approved = parse_json_arg(args.get("approved_destinations_json"), DEFAULT_APPROVED_DEST_WHITELIST)
    result = check_dest(dest, approved)
    return_xsoar_result("DLPApprovedDestCheck", result)


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
