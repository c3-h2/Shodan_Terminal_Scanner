
# This file is generated for Cortex XSOAR 6.12+ Python 3 automations.
# It intentionally uses only Python standard library + XSOAR CommonServerPython primitives.

import json
import re
import ipaddress
from typing import Any, Dict, List, Optional, Tuple

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    # Allows local syntax checks / unit tests outside XSOAR.
    pass


SEVERITY_NAME_TO_NUM = {
    "UNKNOWN": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def str_arg(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def bool_arg_local(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")


def normalize(value: Any) -> str:
    return str_arg(value).strip().lower()


def contains_ci(haystack: Any, needle: Any) -> bool:
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h


def contains_any_ci(haystack: Any, needles: List[str]) -> bool:
    h = normalize(haystack)
    return any(n.lower() in h for n in needles if n)


def split_rules(category: Any) -> List[str]:
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(";") if r.strip()]


def parse_json_arg(value: Any, default: Any) -> Any:
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def parse_csv(value: Any) -> List[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def extract_ips(value: Any) -> List[str]:
    text = str_arg(value)
    # IPv4 only is enough for Forcepoint dest strings in the source pseudo-code.
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)


def is_private_rfc1918(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False


def is_loopback_ip(ip_text: str) -> bool:
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False


def risk_to_num(risk_level: str) -> int:
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)


def get_xsoar_args() -> Dict[str, Any]:
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}


def return_xsoar_result(prefix: str, outputs: Dict[str, Any], readable: Optional[str] = None) -> None:
    try:
        readable_output = readable if readable is not None else tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable_output))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps(outputs, indent=2, ensure_ascii=False))

FTP_CLIENT_PATTERNS = [
    "filezilla", "winscp", "file transfer program", "ftp client",
    "cute ftp", "core ftp", "smartftp", "ftpuse", "lftp",
]

FTP_RULE_KEYWORDS = ["ftp actions", "ftp action", "ftp transfer"]

BACKUP_KEYWORDS = ["backup", "yedek", "full_backup", "dump"]

FINANCIAL_KEYWORDS = [
    "fatura", "finance", "finansal", "banka", "bank",
    "musteri", "müşteri", "customer", "kart", "card",
    "kredi", "credit", "hesap", "account", "odeme", "ödeme", "payment",
    "swift", "iban", "tckn", "kvkk", "gizli", "confidential",
    "qsr", "salary", "maas", "maaş", "bordro", "payroll",
    "sozlesme", "sözleşme", "contract",
]

DEV_KEYWORDS = [
    "project", "method", "telco", "arsiv", "arşiv",
    "archive", "log", "config", "setup", "install",
]

TEST_PREFIX_LIMITS_KB = {
    "den": 50,
    "test": 100,
    "deneme": 100,
    "sample": 100,
    "demo": 100,
}


def _basename(object_name: str) -> str:
    raw = str_arg(object_name).split(" - ")[0]
    raw = raw.replace("\\", "/")
    return raw.rsplit("/", 1)[-1]


def extract_size_kb(object_name: str) -> Optional[float]:
    # Supports strings like: "file.zip - 2.55 KB", "file.zip - 1 MB"
    m = re.search(r"-\s*([0-9]+(?:[.,][0-9]+)?)\s*(KB|MB|GB|B)\b", str_arg(object_name), re.IGNORECASE)
    if not m:
        return None
    value = float(m.group(1).replace(",", "."))
    unit = m.group(2).upper()
    if unit == "B":
        return value / 1024.0
    if unit == "KB":
        return value
    if unit == "MB":
        return value * 1024.0
    if unit == "GB":
        return value * 1024.0 * 1024.0
    return None


def analyze_file(object_name: str) -> Dict[str, Any]:
    if not str_arg(object_name).strip():
        return {"file_risk_type": "unknown", "reason": "Object/file name is empty.", "size_kb": None}

    basename = _basename(object_name)
    basename_lower = basename.lower()
    obj_lower = normalize(object_name)
    size_kb = extract_size_kb(object_name)

    if re.search(r"^(trv|rpt|exp|extract|report|data|export)[_-]\d{4,8}", basename_lower):
        return {"file_risk_type": "automated_export", "reason": "Date-prefixed export/archive pattern matched.", "size_kb": size_kb}

    for kw in BACKUP_KEYWORDS:
        if kw in obj_lower:
            return {"file_risk_type": "backup", "reason": "Backup keyword matched: {}".format(kw), "size_kb": size_kb}

    for kw in FINANCIAL_KEYWORDS:
        if kw in obj_lower:
            return {"file_risk_type": "financial", "reason": "Financial/sensitive keyword matched: {}".format(kw), "size_kb": size_kb}

    for prefix, max_size in TEST_PREFIX_LIMITS_KB.items():
        if basename_lower.startswith(prefix) and (size_kb is None or size_kb <= max_size):
            return {"file_risk_type": "test_file", "reason": "Test prefix matched and size is within threshold.", "size_kb": size_kb}

    for kw in DEV_KEYWORDS:
        if kw in obj_lower:
            return {"file_risk_type": "dev_project", "reason": "Developer/technical keyword matched: {}".format(kw), "size_kb": size_kb}

    return {"file_risk_type": "unknown", "reason": "No file risk pattern matched.", "size_kb": size_kb}


def check_ftp(dest: str, category: str, object_name: str) -> Dict[str, Any]:
    dest_lower = normalize(dest)
    cat_lower = normalize(category)

    ftp_client = None
    for pattern in FTP_CLIENT_PATTERNS:
        if pattern in dest_lower:
            ftp_client = pattern
            break

    rule_match = None
    for kw in FTP_RULE_KEYWORDS:
        if kw in cat_lower:
            rule_match = kw
            break

    is_ftp = bool(ftp_client or rule_match)
    if not is_ftp:
        return {
            "is_ftp": False,
            "risk_level": None,
            "ftp_client": None,
            "file_risk_type": None,
            "reason": "No FTP client/rule indicator matched.",
            "server_note": None,
        }

    file_analysis = analyze_file(object_name)
    file_risk_type = file_analysis["file_risk_type"]
    high_types = ("financial", "backup", "automated_export", "unknown")
    risk_level = "HIGH" if file_risk_type in high_types else "MEDIUM"

    return {
        "is_ftp": True,
        "risk_level": risk_level,
        "ftp_client": ftp_client,
        "file_risk_type": file_risk_type,
        "reason": file_analysis["reason"],
        "size_kb": file_analysis.get("size_kb"),
        "server_note": "Forcepoint Endpoint DLP usually stores FTP client name in dest, not the real FTP server. Validate server via pcap/proxy/network logs.",
    }


def main() -> None:
    args = get_xsoar_args()
    dest = str_arg(args.get("dest"))
    category = str_arg(args.get("category"))
    object_name = str_arg(args.get("object_name"))
    result = check_ftp(dest, category, object_name)
    return_xsoar_result("DLPFTPCheck", result)


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
