
# This file is generated for Cortex XSOAR 6.12+ Python 3 automations.
# It intentionally uses only Python standard library + XSOAR CommonServerPython primitives.

import json
import re
import ipaddress
from typing import Any, Dict, List, Optional, Tuple

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    # Allows local syntax checks / unit tests outside XSOAR.
    pass


SEVERITY_NAME_TO_NUM = {
    "UNKNOWN": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def str_arg(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def bool_arg_local(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")


def normalize(value: Any) -> str:
    return str_arg(value).strip().lower()


def contains_ci(haystack: Any, needle: Any) -> bool:
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h


def contains_any_ci(haystack: Any, needles: List[str]) -> bool:
    h = normalize(haystack)
    return any(n.lower() in h for n in needles if n)


def split_rules(category: Any) -> List[str]:
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(";") if r.strip()]


def parse_json_arg(value: Any, default: Any) -> Any:
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def parse_csv(value: Any) -> List[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def extract_ips(value: Any) -> List[str]:
    text = str_arg(value)
    # IPv4 only is enough for Forcepoint dest strings in the source pseudo-code.
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)


def is_private_rfc1918(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False


def is_loopback_ip(ip_text: str) -> bool:
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False


def risk_to_num(risk_level: str) -> int:
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)


def get_xsoar_args() -> Dict[str, Any]:
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}


def return_xsoar_result(prefix: str, outputs: Dict[str, Any], readable: Optional[str] = None) -> None:
    try:
        readable_output = readable if readable is not None else tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable_output))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps(outputs, indent=2, ensure_ascii=False))

DEFAULT_AI_TOOLS = [
    {"domain": "claude.ai", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.anthropic.com", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chat.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chatgpt.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "gemini.google.com", "name": "Gemini", "vendor": "Google"},
    {"domain": "copilot.microsoft.com", "name": "Copilot", "vendor": "Microsoft"},
    {"domain": "githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
    {"domain": "api.githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
    {"domain": "proxy.business.githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
    {"domain": "proxy.individual.githubcopilot.com", "name": "GitHub Copilot", "vendor": "GitHub"},
]

HIGH_RISK_KEYWORDS = [
    "credit card", "turkey protection of personal data", "kvkk",
    "db fingerprint", "yonetici onay", "yönetici onay", "mali isler", "mali işler",
    "musteri bilgisi", "müşteri bilgisi", "ftkw", "tckn", "iban",
]

MEDIUM_RISK_KEYWORDS = [
    "bulk data remover", "boldon james", "fingerprint",
]

LOW_RISK_KEYWORDS = [
    "sifreli dosya", "şifreli dosya", "7zip encrypted", "video upload blocking", "test ai",
]


def _match_ai_tool(dest: str, ai_tools: List[Dict[str, str]]) -> Optional[Dict[str, str]]:
    for tool in ai_tools:
        if contains_ci(dest, tool.get("domain", "")):
            return tool
    return None


def _keyword_match(rules: List[str], keywords: List[str]) -> Optional[str]:
    for rule in rules:
        for kw in keywords:
            if kw.lower() in rule:
                return kw
    return None


def check_ai_tool(dest: str, category: str, ai_tools: Optional[List[Dict[str, str]]] = None) -> Dict[str, Any]:
    tools = ai_tools or DEFAULT_AI_TOOLS
    matched_tool = _match_ai_tool(dest, tools)
    if not matched_tool:
        return {
            "is_ai_tool": False,
            "risk_level": None,
            "tool_name": None,
            "vendor": None,
            "matched": None,
            "reason": "Destination is not in AI tool list.",
            "rules_parsed": split_rules(category),
        }

    rules = split_rules(category)
    high_kw = _keyword_match(rules, HIGH_RISK_KEYWORDS)
    if high_kw:
        risk, reason = "HIGH", "AI tool destination with high-risk DLP rule keyword: {}".format(high_kw)
    else:
        low_kw = _keyword_match(rules, LOW_RISK_KEYWORDS)
        if low_kw:
            risk, reason = "LOW", "AI tool destination with low-risk/test-like rule keyword: {}".format(low_kw)
        else:
            med_kw = _keyword_match(rules, MEDIUM_RISK_KEYWORDS)
            if med_kw:
                risk, reason = "MEDIUM", "AI tool destination with medium-risk DLP rule keyword: {}".format(med_kw)
            else:
                risk, reason = "MEDIUM", "AI tool destination with unknown DLP rule; conservative medium risk."

    return {
        "is_ai_tool": True,
        "risk_level": risk,
        "tool_name": matched_tool.get("name"),
        "vendor": matched_tool.get("vendor"),
        "matched": matched_tool.get("domain"),
        "reason": reason,
        "rules_parsed": rules,
    }


def main() -> None:
    args = get_xsoar_args()
    dest = str_arg(args.get("dest"))
    category = str_arg(args.get("category"))
    ai_tools = parse_json_arg(args.get("ai_tools_json"), DEFAULT_AI_TOOLS)
    result = check_ai_tool(dest, category, ai_tools)
    return_xsoar_result("DLPAIToolCheck", result)


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
