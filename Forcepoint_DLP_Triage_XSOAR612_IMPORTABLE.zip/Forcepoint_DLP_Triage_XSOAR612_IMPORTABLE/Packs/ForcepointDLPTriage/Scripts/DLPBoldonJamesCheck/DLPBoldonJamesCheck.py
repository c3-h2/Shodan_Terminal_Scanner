
# This file is generated for Cortex XSOAR 6.12+ Python 3 automations.
# It intentionally uses only Python standard library + XSOAR CommonServerPython primitives.

import json
import re
import ipaddress
from typing import Any, Dict, List, Optional, Tuple

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    # Allows local syntax checks / unit tests outside XSOAR.
    pass


SEVERITY_NAME_TO_NUM = {
    "UNKNOWN": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def str_arg(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def bool_arg_local(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")


def normalize(value: Any) -> str:
    return str_arg(value).strip().lower()


def contains_ci(haystack: Any, needle: Any) -> bool:
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h


def contains_any_ci(haystack: Any, needles: List[str]) -> bool:
    h = normalize(haystack)
    return any(n.lower() in h for n in needles if n)


def split_rules(category: Any) -> List[str]:
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(";") if r.strip()]


def parse_json_arg(value: Any, default: Any) -> Any:
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def parse_csv(value: Any) -> List[str]:
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def extract_ips(value: Any) -> List[str]:
    text = str_arg(value)
    # IPv4 only is enough for Forcepoint dest strings in the source pseudo-code.
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)


def is_private_rfc1918(ip_text: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False


def is_loopback_ip(ip_text: str) -> bool:
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False


def risk_to_num(risk_level: str) -> int:
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)


def get_xsoar_args() -> Dict[str, Any]:
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}


def return_xsoar_result(prefix: str, outputs: Dict[str, Any], readable: Optional[str] = None) -> None:
    try:
        readable_output = readable if readable is not None else tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable_output))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps(outputs, indent=2, ensure_ascii=False))

AI_TOOL_DOMAINS = [
    "claude.ai", "api.anthropic.com", "api.openai.com", "chat.openai.com",
    "chatgpt.com", "gemini.google.com", "copilot.microsoft.com",
    "githubcopilot.com", "api.githubcopilot.com", "proxy.business.githubcopilot.com",
    "proxy.individual.githubcopilot.com",
]

PERSONAL_EMAIL_PATTERNS = [
    "gmail", "hotmail", "icloud", "windowslive", "outlook.com",
    "live.com", "yandex",
]


def detect_rule_subtype(category: str) -> str:
    cat = normalize(category)
    if "test" in cat:
        return "test"
    if "yonetici onay" in cat or "yönetici onay" in cat:
        return "yonetici_onay"
    if "db fingerprint" in cat:
        return "db_fingerprint"
    if "turkey" in cat or "kvkk" in cat or "kvk" in cat:
        return "turkey_pd"
    if "musteri bilgisi" in cat or "müşteri bilgisi" in cat:
        return "musteri_bilgisi"
    if "bulk data" in cat:
        return "bulk_data"
    if "fingerprint" in cat:
        return "fingerprint"
    return "standard"


def classify_dest(dest: str) -> str:
    d = normalize(dest)
    if contains_any_ci(d, PERSONAL_EMAIL_PATTERNS):
        return "personal_email"
    if "riskmerkezi" in d:
        return "authorized_partner"
    if "@kkb.com.tr" in d or ".kkb.com.tr" in d or d.endswith("kkb.com.tr"):
        return "internal"
    if d in ("smtp", "endpoint https") or "endpoint https" in d:
        return "generic_channel"
    return "corporate_external"


def check_bj(dest: str, category: str, skip_if_ai_tool: bool = True) -> Dict[str, Any]:
    is_ai = contains_any_ci(dest, AI_TOOL_DOMAINS)
    if skip_if_ai_tool and is_ai:
        return {
            "is_bj": "boldon james" in normalize(category),
            "skipped": True,
            "risk_level": None,
            "dest_type": None,
            "rule_subtype": None,
            "reason": "Skipped because destination matched AI tool; AI triage should be authoritative.",
        }

    if "boldon james" not in normalize(category):
        return {
            "is_bj": False,
            "skipped": False,
            "risk_level": None,
            "dest_type": None,
            "rule_subtype": None,
            "reason": "Category is not Boldon James.",
        }

    subtype = detect_rule_subtype(category)
    dest_type = classify_dest(dest)

    if subtype == "test":
        risk, reason = "LOW", "Boldon James test rule."
    elif dest_type == "personal_email":
        risk, reason = "HIGH", "Boldon James data to personal email destination."
    elif subtype in ("yonetici_onay", "db_fingerprint", "turkey_pd", "musteri_bilgisi"):
        risk, reason = "HIGH", "Sensitive Boldon James subtype."
    elif dest_type == "authorized_partner":
        if subtype in ("fingerprint", "bulk_data"):
            risk, reason = "MEDIUM", "Authorized partner with fingerprint/bulk subtype."
        else:
            risk, reason = "LOW", "Authorized partner with standard/test-like subtype."
    elif dest_type == "internal":
        risk, reason = "LOW", "Internal destination."
    else:
        # corporate_external or generic_channel
        if subtype in ("yonetici_onay", "db_fingerprint", "turkey_pd", "musteri_bilgisi"):
            risk, reason = "HIGH", "Sensitive subtype to external/generic destination."
        else:
            risk, reason = "MEDIUM", "Boldon James standard/bulk/fingerprint to external/generic destination."

    return {
        "is_bj": True,
        "skipped": False,
        "risk_level": risk,
        "dest_type": dest_type,
        "rule_subtype": subtype,
        "reason": reason,
    }


def main() -> None:
    args = get_xsoar_args()
    dest = str_arg(args.get("dest"))
    category = str_arg(args.get("category"))
    skip_if_ai_tool = bool_arg_local(args.get("skip_if_ai_tool"), True)
    result = check_bj(dest, category, skip_if_ai_tool)
    return_xsoar_result("DLPBoldonJamesCheck", result)


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
