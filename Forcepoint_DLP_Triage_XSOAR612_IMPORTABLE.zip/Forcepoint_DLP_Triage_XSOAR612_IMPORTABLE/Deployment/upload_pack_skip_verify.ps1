param(
  [Parameter(Mandatory=$true)][string]$XsoarUrl,
  [Parameter(Mandatory=$true)][string]$ApiKey,
  [string]$PackFile = "..\ForcepointDLPTriage_pack_with_Packs_root.zip"
)

# Use this only for a reviewed internal/dev pack. It skips Marketplace signature verification.
# For self-signed certs on PowerShell 7+, use -SkipCertificateCheck.

$uri = $XsoarUrl.TrimEnd('/') + "/contentpacks/installed/upload"
$headers = @{ Authorization = $ApiKey }
$form = @{
  skipVerify = 'true'
  skipValidation = 'false'
  file = Get-Item $PackFile
}

try {
  Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Form $form -SkipCertificateCheck | ConvertTo-Json -Depth 20
} catch {
  Write-Error $_
  exit 1
}
