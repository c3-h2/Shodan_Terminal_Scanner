#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   export XSOAR_URL="https://xsoar.example.local"
#   export XSOAR_API_KEY="<api-key>"
#   ./upload_pack_skip_verify.sh ../ForcepointDLPTriage_pack_with_Packs_root.zip
#
# Use this only for a reviewed internal/dev pack. It skips Marketplace signature verification.

PACK_FILE="${1:-../ForcepointDLPTriage_pack_with_Packs_root.zip}"
: "${XSOAR_URL:?Set XSOAR_URL, e.g. https://xsoar.example.local}"
: "${XSOAR_API_KEY:?Set XSOAR_API_KEY}"

curl -k -sS -X POST \
  -H "Authorization: ${XSOAR_API_KEY}" \
  "${XSOAR_URL%/}/contentpacks/installed/upload" \
  -F "skipVerify=true" \
  -F "skipValidation=false" \
  -F "file=@${PACK_FILE}" | python3 -m json.tool || true
