param(
  [Parameter(Mandatory=$true)][string]$XsoarUrl,
  [Parameter(Mandatory=$true)][string]$ApiKey,
  [string]$UnifiedFolder = "..\UnifiedYAML"
)

# This does NOT upload as a content pack. It imports custom automations and playbook individually.
# Recommended when unsigned pack import is blocked by policy.

$baseUrl = $XsoarUrl.TrimEnd('/')
$headers = @{ Authorization = $ApiKey }

Get-ChildItem $UnifiedFolder -Filter 'automation-*.yml' | ForEach-Object {
  Write-Host "Importing automation: $($_.FullName)"
  $form = @{ file = $_ }
  Invoke-RestMethod -Method Post -Uri "$baseUrl/automation/import" -Headers $headers -Form $form -SkipCertificateCheck | ConvertTo-Json -Depth 20
}

Get-ChildItem $UnifiedFolder -Filter 'playbook-*.yml' | ForEach-Object {
  Write-Host "Importing playbook: $($_.FullName)"
  $form = @{ file = $_ }
  Invoke-RestMethod -Method Post -Uri "$baseUrl/playbook/save/yaml" -Headers $headers -Form $form -SkipCertificateCheck | ConvertTo-Json -Depth 20
}
