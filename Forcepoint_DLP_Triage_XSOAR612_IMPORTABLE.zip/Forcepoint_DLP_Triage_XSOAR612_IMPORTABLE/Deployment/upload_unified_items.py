#!/usr/bin/env python3
import argparse, mimetypes, os, ssl, urllib.request
from pathlib import Path
from uuid import uuid4

def multipart_form(fields, files):
    boundary = '----xsoar' + uuid4().hex
    body = bytearray()
    for name, value in fields.items():
        body.extend(f'--{boundary}\r\n'.encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    for name, path in files.items():
        path = Path(path)
        ctype = mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
        body.extend(f'--{boundary}\r\n'.encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"; filename="{path.name}"\r\n'.encode())
        body.extend(f'Content-Type: {ctype}\r\n\r\n'.encode())
        body.extend(path.read_bytes())
        body.extend(b'\r\n')
    body.extend(f'--{boundary}--\r\n'.encode())
    return bytes(body), f'multipart/form-data; boundary={boundary}'

def post_file(base_url, api_key, endpoint, file_path, insecure=False, fields=None):
    body, content_type = multipart_form(fields or {}, {'file': file_path})
    req = urllib.request.Request(base_url.rstrip('/') + endpoint, data=body, headers={
        'Authorization': api_key, 'Content-Type': content_type, 'Accept': 'application/json'}, method='POST')
    ctx = ssl._create_unverified_context() if insecure else None
    with urllib.request.urlopen(req, context=ctx, timeout=120) as resp:
        return resp.status, resp.read().decode('utf-8', errors='replace')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--url', default=os.getenv('XSOAR_URL'), required=not bool(os.getenv('XSOAR_URL')))
    p.add_argument('--api-key', default=os.getenv('XSOAR_API_KEY'), required=not bool(os.getenv('XSOAR_API_KEY')))
    p.add_argument('--folder', default='../UnifiedYAML')
    p.add_argument('--insecure', action='store_true')
    args = p.parse_args()
    folder = Path(args.folder)
    for yml in sorted(folder.glob('automation-*.yml')):
        status, text = post_file(args.url, args.api_key, '/automation/import', yml, args.insecure)
        print(f'[{status}] automation {yml.name}: {text[:500]}')
    for yml in sorted(folder.glob('playbook-*.yml')):
        status, text = post_file(args.url, args.api_key, '/playbook/save/yaml', yml, args.insecure)
        print(f'[{status}] playbook {yml.name}: {text[:500]}')
if __name__ == '__main__': main()
