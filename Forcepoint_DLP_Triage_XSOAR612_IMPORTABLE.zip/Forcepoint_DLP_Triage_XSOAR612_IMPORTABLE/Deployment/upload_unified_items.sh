#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   export XSOAR_URL="https://xsoar.example.local"
#   export XSOAR_API_KEY="<api-key>"
#   ./upload_unified_items.sh
#
# This does NOT upload as a content pack. It imports custom automations and playbook individually.
# Recommended when unsigned pack import is blocked by policy.

: "${XSOAR_URL:?Set XSOAR_URL, e.g. https://xsoar.example.local}"
: "${XSOAR_API_KEY:?Set XSOAR_API_KEY}"
BASE="${1:-../UnifiedYAML}"

for file in "$BASE"/automation-*.yml; do
  echo "Importing automation: $file"
  curl -k -sS -X POST \
    -H "Authorization: ${XSOAR_API_KEY}" \
    -H 'Accept: application/json' \
    "${XSOAR_URL%/}/automation/import" \
    -F "file=@${file}" >/tmp/xsoar_upload_resp.txt
  cat /tmp/xsoar_upload_resp.txt; echo
done

for file in "$BASE"/playbook-*.yml; do
  echo "Importing playbook: $file"
  curl -k -sS -X POST \
    -H "Authorization: ${XSOAR_API_KEY}" \
    -H 'Accept: application/json' \
    "${XSOAR_URL%/}/playbook/save/yaml" \
    -F "file=@${file}" >/tmp/xsoar_upload_resp.txt
  cat /tmp/xsoar_upload_resp.txt; echo
done
