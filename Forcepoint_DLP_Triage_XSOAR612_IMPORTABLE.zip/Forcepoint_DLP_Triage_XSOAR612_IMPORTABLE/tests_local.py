#!/usr/bin/env python3
"""Minimal local sanity tests for DLPForcepointMasterTriage pure triage logic.

Run outside XSOAR:
    python tests_local.py
"""

import importlib.util
import json
from pathlib import Path

script_path = Path(__file__).parent / "Scripts" / "DLPForcepointMasterTriage" / "DLPForcepointMasterTriage.py"
spec = importlib.util.spec_from_file_location("master", script_path)
master = importlib.util.module_from_spec(spec)
spec.loader.exec_module(master)

cases = json.loads((Path(__file__).parent / "TestData" / "sample_incidents.json").read_text(encoding="utf-8"))

for case in cases:
    incident = {"dest": case["dest"], "category": case["category"], "object": case.get("object", "")}
    result = master.triage(incident, {})
    assert result["tag"] == case["expected_tag"], (case["name"], result["tag"], case["expected_tag"], result)
    print("PASS", case["name"], result["tag"], result["severity"])
