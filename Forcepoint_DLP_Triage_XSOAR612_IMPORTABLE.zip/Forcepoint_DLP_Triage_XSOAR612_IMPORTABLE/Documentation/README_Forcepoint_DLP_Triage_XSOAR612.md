# Forcepoint DLP Alarm Otomatik Triaj Sistemi — XSOAR 6.12 / Forcepoint DLP 10.2

Bu paket, sağlanan pseudo kodun XSOAR 6.12 üzerinde kullanılabilir hale getirilmiş sürümüdür.

## İçerik

- `Scripts/DLPForcepointMasterTriage`: Master orchestration automation. Incident üzerinde severity/label atar ve yüksek güvenli FP durumlarında kapatır.
- `Scripts/DLPFPDestCheck`: GitHub Copilot destination whitelist kontrolü.
- `Scripts/DLPLocalDestCheck`: localhost/loopback/onaylı internal dev server/RFC1918 kontrolü.
- `Scripts/DLPApprovedDestCheck`: onaylı hedef whitelist kontrolü.
- `Scripts/DLPAIToolCheck`: AI tool destination + DLP rule risk sınıflandırması.
- `Scripts/DLPBoldonJamesCheck`: Boldon James alt kural × hedef tipi risk matrisi.
- `Scripts/DLPFTPCheck`: FTP client/rule + object/file-name risk sınıflandırması.
- `Playbooks/playbook-DLP_Master_Triage.yml`: Tek task ile master automation çağıran playbook.

## Forcepoint DLP 10.2 Field Mapping

Paket varsayılan olarak aşağıdaki incident alanlarını bekler:

| Pseudo field | XSOAR arg default | Açıklama |
|---|---|---|
| `incident.dest` | `dest_field=dest` | HTTPS/web alarmlarında domain/IP. FTP Endpoint alarmlarında FTP client adı olabilir. |
| `incident.category` | `category_field=category` | Forcepoint DLP rule/policy/category adı. `;` ile ayrılmış çoklu kural desteklenir. |
| `incident.app` | `app_field=app` | Alarmı tetikleyen uygulama. |
| `incident.object` | `object_field=object` | Dosya adı/yolu/boyutu. Örn: `file.zip - 2.55 KB`. |

Eğer kurumunuzda Forcepoint DLP classifier/mapper farklı custom field adları üretiyorsa, playbook task argümanlarında şu alanları değiştirin:

```text
dest_field=<custom field cliName>
category_field=<custom field cliName>
app_field=<custom field cliName>
object_field=<custom field cliName>
```

Automation resolver sırası:
1. explicit automation arg (`dest`, `category`, `app`, `object_name`)
2. top-level incident field
3. `CustomFields` / `customFields`
4. incident labels

## Önerilen XSOAR Kurulum Adımları

1. ZIP dosyasını XSOAR Content Management / Import Pack üzerinden içeri alın.
2. `DLPForcepointMasterTriage` automation'ını test incident üzerinde önce `dry_run=true` ile çalıştırın.
3. Field mapping doğruysa playbook task içinde `dry_run=false` bırakın.
4. Forcepoint DLP incident type için default playbook olarak `DLP_Master_Triage` atayın.
5. İlk 1-2 hafta `close_incident=false` ile gözlem yapın; FP doğrulandıktan sonra `close_incident=true` yapın.
6. Onaylı hedef listelerini hard-code yerine playbook argümanlarından JSON ile yönetin.

## Auto-close Mantığı

Sadece aşağıdaki yüksek güvenli False Positive durumları kapatır:

- Software Source Code + GitHub Copilot whitelist destination.
- Software Source Code / Boldon James / Bulk Data Remover + loopback veya onaylı internal dev server.
- Approved destination listesinde `confidence=HIGH` olan hedefler.

Aşağıdakiler kapatılmaz, sadece severity/tag atanır:

- AI tool alarmları.
- Boldon James alarmları.
- FTP alarmları.
- RFC1918 generic private IP eşleşmeleri.
- Approved destination `confidence=MEDIUM`.

## XSOAR Severity Mapping

| Risk | XSOAR severity |
|---|---:|
| LOW | 1 |
| MEDIUM | 2 |
| HIGH | 3 |
| CRITICAL | 4 |

## Incident Labels

Automation incident'a aşağıdaki labels eklemeye çalışır:

- `dlp_triage_tag`
- `dlp_triage_action`
- `dlp_triage_reason`
- `dlp_triage_matched`

Labels kullanıldığı için custom incident field oluşturmak zorunlu değildir.

## Önemli Notlar

- FTP için Forcepoint Endpoint DLP `dest` alanında gerçek FTP server yerine FTP client adı tutabilir. Gerçek server için pcap/proxy/network log korelasyonu gerekir.
- AI Triage eşleşirse Boldon James matrisi skipped olur; daha spesifik AI sınıflandırması korunur.
- Master automation severity'yi düşürmez; bir branch HIGH verdiyse sonraki LOW/MEDIUM branch bunu overwrite etmez.
