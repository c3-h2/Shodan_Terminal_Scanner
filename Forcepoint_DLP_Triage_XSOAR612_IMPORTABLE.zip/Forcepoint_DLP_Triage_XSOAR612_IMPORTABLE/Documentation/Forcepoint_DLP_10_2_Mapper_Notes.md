# Forcepoint DLP 10.2 → XSOAR 6.12 Mapper Notları

Bu paket field mapping'i argümanlarla esnek bırakır. Yine de production kullanım için Forcepoint DLP incident type mapper'da aşağıdaki normalize alanları üretmeniz önerilir.

## Minimum Alanlar

| Forcepoint DLP Kaynağı | XSOAR alanı/custom field | Master arg |
|---|---|---|
| Destination / URL / Endpoint destination | `dest` veya kurum custom field cliName'i | `dest_field` |
| Policy / Rule / Category | `category` veya kurum custom field cliName'i | `category_field` |
| Application / Channel | `app` veya kurum custom field cliName'i | `app_field` |
| Object / File Name / File Path / Size | `object` veya kurum custom field cliName'i | `object_field` |

## Test Komutu

Test incident üzerinde:

```text
!DLPForcepointMasterTriage dry_run=true dest="chatgpt.com" category="KVKK; Credit Card" object_name="customer_data.xlsx - 4 MB"
```

Beklenen sonuç:

```text
action=set_severity
severity=HIGH
tag=ai-tool-high-risk
manual_review_required=true
```

## Production Öncesi Gate

- 20 bilinen FP incident ile dry-run.
- 20 gerçek pozitif / hassas veri incident ile dry-run.
- Auto-close sadece `close_incident=false` gözlem döneminden sonra açılmalı.
- `approved_destinations_json` listesindeki HIGH confidence kayıtları Change Management onayından geçmeli.
