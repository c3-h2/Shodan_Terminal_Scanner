# DLP XSOAR 6.14 Automation & Playbook Paketi

Bu paket, sağlanan pseudo-code belgesindeki 9 automation ve 17 playbook akışını XSOAR 6.14 YAML formatında üretir.

## İçerik

### Automations
1. DLPFPDestCheck
2. DLPApprovedDestCheck
3. DLPLocalDestCheck
4. DLPAIToolCheck
5. DLPBoldonJamesCheck
6. DLPFTPCheck
7. DLPCrowdStrikeEvidence
8. DLPSplunkESSEvidence
9. DLPEvidenceDecisionEngine

### Playbooks
1. DLP_GithubCopilot_Autoclose
2. DLP_Localhost_Autoclose
3. DLP_ApprovedDest_Autoclose
4. DLP_AITool_Triage
5. DLP_BoldonJames_Triage
6. DLP_FTPAction_Triage
7. DLP_BulkDataRemover_Triage
8. DLP_SoftwareSourceCode_Triage
9. DLP_CreditCards_Policy_Triage
10. DLP_MusteriBilgisiBelge_Triage
11. DLP_SifreliDosyaKontrolu_Triage
12. DLP_VideoUploadBlocking_Triage
13. DLP_BoldonJames_Policy_Triage
14. DLP_7ZipEncryptedFile_Triage
15. DLP_LongTail_ManualReview
16. DLP_Master_Triage
17. DLP_Master_VolumeBased_Triage

## Import sırası

Ortamınız unsigned content pack importuna izin vermiyorsa, root klasördeki manuel import kopyalarını aşağıdaki sırayla yükleyin:

1. `Script-*.yml` dosyalarının tamamı.
2. Leaf playbooklar: Autoclose ve Triage playbookları.
3. Evidence playbookları: `DLP_BulkDataRemover_Triage`, `DLP_SoftwareSourceCode_Triage`.
4. Master playbooklar: `DLP_Master_Triage`, `DLP_Master_VolumeBased_Triage`.

## Splunk evidence inputları

Evidence playbookları boş SPL ile gelir. Ortamınıza göre aşağıdaki inputları set edin:

- `SplunkCommand`: varsayılan `splunk-search`
- `SplunkQueryArgName`: varsayılan `query`
- `ProxySplunkQuery`: `{dest}`, `{user}`, `{src}`, `{category}`, `{object}`, `{app}`, `{raw}` placeholderlarını destekler.
- `FirewallSplunkQuery`: aynı placeholderları destekler.
- `SplunkExtraArgsJSON`: örn. `{"earliest_time":"-24h","latest_time":"now"}`

Örnek proxy SPL şablonu:

```spl
search index=proxy earliest=-24h latest=now (url="*{dest}*" OR dest="{dest}" OR user="{user}")
| table _time user src dest url action app
| head 50
```

Örnek firewall SPL şablonu:

```spl
search index=firewall earliest=-24h latest=now (dest_ip="{dest}" OR dest="{dest}" OR src="{src}")
| table _time src dest_ip dest_port action rule
| head 50
```

## CrowdStrike notu

`DLPCrowdStrikeEvidence`, XSOAR ortamlarında CrowdStrike command argüman adlarının değişebilmesi ihtimaline karşı aynı komutu farklı argüman varyantlarıyla dener. Yine de entegrasyonunuzdaki command adı farklıysa automation içinde `cs-falcon-*` komut adlarını uyarlayın.

## Güvenli çalışma notları

- `claude.ai` ve `api.anthropic.com` gibi AI hedefleri auto-close whitelist’e eklenmemiştir; sadece risk sınıflandırmasına girer.
- FTP akışında otomatik kapatma yoktur; minimum MEDIUM inceleme üretilir.
- HIGH confidence whitelist/local eşleşmeleri closeInvestigation ile False Positive kapatır.
- MEDIUM confidence approved/local eşleşmeleri düşük öncelikli analist doğrulamasına yönlendirilir.
