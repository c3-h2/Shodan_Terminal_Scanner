# Infoblox IPAM Scheduled Export – XSOAR 6.14

## Amaç

Bu automation her çalıştırmada yalnızca bir subnet batch'i işler. Checkpoint ve birikmiş CSV verisi XSOAR List içinde gzip+Base64 olarak saklanır. Son batch tamamlandığında tek CSV oluşturulur, War Room'a eklenir ve `send-mail` komutuyla e-posta eki olarak gönderilir.

## Ön koşullar

- Çalışan `Infoblox IPAM V2` instance'ı ve `infoblox-ipam-list-all-used-ips` komutu.
- Çalışan `Mail Sender (New)` instance'ı ve `send-mail` komutu.
- Automation'ın XSOAR List okuma/yazma yetkisi.

## Import

Settings > Integrations > Automation > Upload Automation alanından `InfobloxIPAMScheduledExport.yml` dosyasını yükleyin.

## İlk manuel test

```text
!InfobloxIPAMScheduledExport mail_to="soc@example.com" network_view="default" network_limit="25" minimum_interval_hours="24"
```

Komut ilk çalıştırmada yalnızca ilk batch'i toplar. Aynı komutu tekrar çalıştırdığınızda checkpoint'ten devam eder. Son batch'te tek CSV üretilir ve e-posta gönderilir.

## Periyodik çalıştırma

War Room Scheduled Command veya Job içindeki automation task'ını 5 dakikada bir çalıştırın. Automation tamamlanan bir rapordan sonra `minimum_interval_hours` dolana kadar yeni toplama başlatmaz.

Önerilen parametreler:

```text
mail_to="soc@example.com"
network_view="default"
network_limit="25"
max_records_per_batch="50000"
minimum_interval_hours="24"
state_list_name="InfobloxIPAMScheduledExportState"
send_partial_on_failed_networks="true"
```

## Manuel sıfırlama

```text
!InfobloxIPAMScheduledExport mail_to="soc@example.com" reset="true"
```

## İşleyiş

1. State listesi yoksa yeni toplama başlatılır.
2. `network_offset` checkpoint'inden bir batch subnet taranır.
3. IP kayıtları CSV satırlarına çevrilip sıkıştırılarak state listesine eklenir.
4. Sonraki scheduled execution kaldığı offset'ten devam eder.
5. Son batch tamamlanınca CSV Mail Sender (New) üzerinden gönderilir.
6. Büyük IP listesi incident context'e kalıcı olarak yazılmaz.
