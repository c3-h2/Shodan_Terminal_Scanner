# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

COPILOT_WHITELIST = [
    "proxy.business.githubcopilot.com",
    "proxy.individual.githubcopilot.com",
    "api.githubcopilot.com",
    "api.github.com/chunks",
    "githubcopilot.com",
]

def check(dest, category, whitelist):
    in_scope = contains_ci(category, "Software Source Code")
    result = {
        "InScope": in_scope,
        "IsFP": False,
        "Confidence": "NONE",
        "Matched": None,
        "Category": "github_copilot",
        "RecommendedAction": "none",
        "Severity": None,
        "SeverityNum": None,
        "Tag": None,
        "CloseReason": None,
        "CloseNotes": None,
        "Reason": "Category outside Software Source Code scope." if not in_scope else "No Copilot destination matched.",
        "ManualReviewRequired": False,
        "StopProcessing": False,
    }
    if not in_scope:
        return result
    for entry in whitelist:
        if contains_ci(dest, entry):
            result.update({
                "IsFP": True,
                "Confidence": "HIGH",
                "Matched": entry,
                "RecommendedAction": "auto_close",
                "Severity": "LOW",
                "SeverityNum": 1,
                "Tag": "fp-github-copilot",
                "CloseReason": "False Positive",
                "CloseNotes": "GitHub Copilot proxy/API traffic. Dest: {}".format(dest),
                "Reason": "GitHub Copilot proxy/API traffic matched whitelist.",
                "ManualReviewRequired": False,
                "StopProcessing": True,
            })
            return result
    result.update({
        "RecommendedAction": "set_severity",
        "Severity": "HIGH",
        "SeverityNum": 3,
        "Tag": "ssc-manual-review",
        "Reason": "Software Source Code rule did not match GitHub Copilot FP whitelist.",
        "ManualReviewRequired": True,
    })
    return result

def main():
    args = get_args()
    whitelist = parse_json_arg(args.get('copilot_whitelist_json'), COPILOT_WHITELIST)
    outputs = check(str_arg(args.get('dest')), str_arg(args.get('category')), whitelist)
    return_result('DLP.GitHubCopilot', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
