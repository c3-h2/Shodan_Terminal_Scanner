# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

INTERNAL_DEV_SERVERS = ["10.200.107.112", "10.200.115.23"]
SCOPE_RULES = ["Software Source Code", "Boldon James", "Bulk Data Remover"]

def check(dest, category, internal_servers):
    in_scope = contains_any_ci(category, SCOPE_RULES)
    result = {
        "InScope": in_scope,
        "IsFP": False,
        "Confidence": "NONE",
        "Matched": None,
        "Category": None,
        "RecommendedAction": "none",
        "Severity": None,
        "SeverityNum": None,
        "Tag": None,
        "CloseReason": None,
        "CloseNotes": None,
        "Reason": "Category outside Localhost/Internal scope." if not in_scope else "No localhost/internal destination matched.",
        "ManualReviewRequired": False,
        "StopProcessing": False,
    }
    if not in_scope:
        return result
    d = normalize(dest)
    if "localhost" in d or "127.0.0.1" in d or "::1" in d:
        result.update({
            "IsFP": True, "Confidence": "HIGH", "Matched": "loopback", "Category": "loopback",
            "RecommendedAction": "auto_close", "Severity": "LOW", "SeverityNum": 1, "Tag": "fp-localhost",
            "CloseReason": "False Positive", "CloseNotes": "Localhost/loopback destination. Dest: {}".format(dest),
            "Reason": "Destination is localhost/loopback.", "ManualReviewRequired": False, "StopProcessing": True,
        })
        return result
    for ip_text in extract_ips(dest):
        if is_loopback_ip(ip_text):
            result.update({
                "IsFP": True, "Confidence": "HIGH", "Matched": ip_text, "Category": "loopback",
                "RecommendedAction": "auto_close", "Severity": "LOW", "SeverityNum": 1, "Tag": "fp-localhost",
                "CloseReason": "False Positive", "CloseNotes": "Loopback IP destination. Dest: {}".format(dest),
                "Reason": "Destination IP is loopback.", "ManualReviewRequired": False, "StopProcessing": True,
            })
            return result
    for server in internal_servers:
        if contains_ci(dest, server):
            result.update({
                "IsFP": True, "Confidence": "HIGH", "Matched": server, "Category": "internal_dev_server",
                "RecommendedAction": "auto_close", "Severity": "LOW", "SeverityNum": 1, "Tag": "fp-localhost",
                "CloseReason": "False Positive", "CloseNotes": "Approved internal development server. Dest: {}".format(dest),
                "Reason": "Approved internal development server.", "ManualReviewRequired": False, "StopProcessing": True,
            })
            return result
    for ip_text in extract_ips(dest):
        if is_private_rfc1918(ip_text):
            result.update({
                "IsFP": True, "Confidence": "MEDIUM", "Matched": ip_text, "Category": "rfc1918_private",
                "RecommendedAction": "set_severity", "Severity": "LOW", "SeverityNum": 1, "Tag": "low-priority-internal",
                "Reason": "RFC1918 private destination; not auto-closed.", "ManualReviewRequired": True,
            })
            return result
    return result

def main():
    args = get_args()
    servers = parse_csv(args.get('internal_dev_servers')) or INTERNAL_DEV_SERVERS
    outputs = check(str_arg(args.get('dest')), str_arg(args.get('category')), servers)
    return_result('DLP.LocalDest', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
