# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

def add_label(label_type, label_value, dry_run=False):
    if dry_run or label_value in (None, ''):
        return []
    try:
        result = demisto.executeCommand('setIncident', {  # type: ignore[name-defined]
            'addLabels': json.dumps([{'type': label_type, 'value': str(label_value)}], ensure_ascii=False)
        })
        return result if isinstance(result, list) else []
    except Exception as ex:
        try:
            demisto.debug('DLP triage label update failed: {}'.format(ex))  # type: ignore[name-defined]
        except Exception:
            pass
        return []

def set_incident_severity(severity_num, dry_run=False):
    if dry_run:
        return []
    try:
        result = demisto.executeCommand('setIncident', {'severity': int(severity_num)})  # type: ignore[name-defined]
        return result if isinstance(result, list) else []
    except Exception as ex:
        try:
            demisto.debug('DLP triage severity update failed: {}'.format(ex))  # type: ignore[name-defined]
        except Exception:
            pass
        return []

def close_incident(close_reason, close_notes, dry_run=False):
    if dry_run:
        return []
    try:
        result = demisto.executeCommand('closeInvestigation', {
            'closeReason': close_reason or 'False Positive',
            'closeNotes': close_notes or 'Closed by DLP triage automation.',
        })  # type: ignore[name-defined]
        return result if isinstance(result, list) else []
    except Exception as ex:
        try:
            demisto.debug('DLP triage closeInvestigation failed: {}'.format(ex))  # type: ignore[name-defined]
        except Exception:
            pass
        return []

def current_severity_from_incident():
    try:
        inc = demisto.incident() or {}  # type: ignore[name-defined]
        val = inc.get('severity')
        if val in (None, ''):
            return 0
        return int(val)
    except Exception:
        return 0

def previous_severity_from_context():
    try:
        ctx = demisto.context() or {}  # type: ignore[name-defined]
        applied = (((ctx.get('DLP') or {}).get('Triage') or {}).get('Applied') or {})
        val = applied.get('SeverityNum')
        if val in (None, ''):
            return 0
        return int(val)
    except Exception:
        return 0

def main():
    args = get_args()
    action = str_arg(args.get('action'), 'none')
    severity = str_arg(args.get('severity'))
    severity_num = int(args.get('severity_num') or risk_to_num(severity or 'MEDIUM'))
    tag = str_arg(args.get('tag'))
    reason = str_arg(args.get('reason'))
    matched = str_arg(args.get('matched'))
    close_reason = str_arg(args.get('close_reason'), 'False Positive')
    close_notes = str_arg(args.get('close_notes'), reason)
    dry_run = bool_arg(args.get('dry_run'), False)
    update_incident = bool_arg(args.get('update_incident'), True)
    close_incident_flag = bool_arg(args.get('close_incident'), False)
    never_lower_severity = bool_arg(args.get('never_lower_severity'), True)

    processed = action in ('set_severity', 'auto_close')
    existing = max(current_severity_from_incident(), previous_severity_from_context())
    effective_sev_num = max(existing, severity_num) if never_lower_severity else severity_num
    effective_severity = next((name for name, num in SEVERITY_NAME_TO_NUM.items() if num == effective_sev_num), severity or 'MEDIUM')
    closed = False
    should_close = action == 'auto_close'

    if processed and update_incident:
        add_label('dlp_triage_tag', tag, dry_run)
        add_label('dlp_triage_action', action, dry_run)
        add_label('dlp_triage_reason', reason[:1000], dry_run)
        if matched:
            add_label('dlp_triage_matched', matched, dry_run)
        if action == 'auto_close':
            # In pilot mode close_incident=false: label the close recommendation, do not close.
            if close_incident_flag:
                close_incident(close_reason, close_notes, dry_run)
                closed = not dry_run
            else:
                set_incident_severity(effective_sev_num, dry_run)
        elif action == 'set_severity':
            set_incident_severity(effective_sev_num, dry_run)

    outputs = {
        'Processed': processed,
        'Action': action,
        'RequestedSeverity': severity,
        'RequestedSeverityNum': severity_num,
        'Severity': effective_severity,
        'SeverityNum': effective_sev_num,
        'Tag': tag,
        'Reason': reason,
        'Matched': matched,
        'ShouldClose': should_close,
        'Closed': closed,
        'StopProcessing': should_close,
        'DryRun': dry_run,
        'UpdateIncident': update_incident,
        'CloseIncident': close_incident_flag,
    }
    return_result('DLP.Triage.Applied', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
