# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

FTP_CLIENT_PATTERNS = ["filezilla", "winscp", "file transfer program", "ftp client", "cute ftp", "core ftp", "smartftp", "ftpuse", "lftp"]
FTP_RULE_KEYWORDS = ["ftp actions", "ftp action", "ftp transfer"]

def extract_size_kb(object_name):
    m = re.search(r"-\s*([0-9]+(?:[.,][0-9]+)?)\s*(KB|MB|GB|B)\b", str_arg(object_name), re.IGNORECASE)
    if not m:
        return None
    value = float(m.group(1).replace(',', '.'))
    unit = m.group(2).upper()
    if unit == 'B':
        return value / 1024.0
    if unit == 'KB':
        return value
    if unit == 'MB':
        return value * 1024.0
    if unit == 'GB':
        return value * 1024.0 * 1024.0
    return None

def basename(object_name):
    raw = str_arg(object_name).split(' - ')[0].replace('\\', '/')
    return raw.rsplit('/', 1)[-1]

def analyze_file(object_name):
    if str_arg(object_name).strip() == '':
        return {"FileRiskType": "unknown", "FileReason": "Object/file name is empty.", "SizeKB": None}
    b = normalize(basename(object_name))
    o = normalize(object_name)
    size_kb = extract_size_kb(object_name)
    if re.search(r"^(trv|rpt|exp|extract|report|data|export)[_-]\d{4,8}", b):
        return {"FileRiskType": "automated_export", "FileReason": "Automated export filename pattern.", "SizeKB": size_kb}
    for kw in ["backup", "yedek", "full_backup", "dump"]:
        if kw in o:
            return {"FileRiskType": "backup", "FileReason": "Backup keyword: {}".format(kw), "SizeKB": size_kb}
    sensitive = ["fatura", "finance", "finansal", "banka", "bank", "musteri", "müşteri", "customer", "kart", "card", "kredi", "credit", "hesap", "account", "odeme", "ödeme", "payment", "swift", "iban", "tckn", "kvkk", "gizli", "confidential", "qsr", "salary", "maas", "maaş", "bordro", "payroll", "sozlesme", "sözleşme", "contract"]
    for kw in sensitive:
        if kw in o:
            return {"FileRiskType": "financial", "FileReason": "Sensitive keyword: {}".format(kw), "SizeKB": size_kb}
    for prefix, max_size in {"den": 50, "test": 100, "deneme": 100, "sample": 100, "demo": 100}.items():
        if b.startswith(prefix) and (size_kb is None or size_kb <= max_size):
            return {"FileRiskType": "test_file", "FileReason": "Test prefix and small/unknown size.", "SizeKB": size_kb}
    for kw in ["project", "method", "telco", "arsiv", "arşiv", "archive", "log", "config", "setup", "install"]:
        if kw in o:
            return {"FileRiskType": "dev_project", "FileReason": "Technical/dev keyword: {}".format(kw), "SizeKB": size_kb}
    return {"FileRiskType": "unknown", "FileReason": "No FTP file pattern matched.", "SizeKB": size_kb}

def check(dest, category, object_name):
    d = normalize(dest)
    c = normalize(category)
    ftp_client = next((p for p in FTP_CLIENT_PATTERNS if p in d), None)
    rule_match = next((kw for kw in FTP_RULE_KEYWORDS if kw in c), None)
    result = {
        "InScope": bool(ftp_client or rule_match),
        "IsFTP": bool(ftp_client or rule_match),
        "RiskLevel": None,
        "FTPClient": ftp_client,
        "RuleMatch": rule_match,
        "FileRiskType": None,
        "FileReason": None,
        "ServerNote": None,
        "RecommendedAction": "none",
        "Severity": None,
        "SeverityNum": None,
        "Tag": None,
        "Reason": "No FTP indicator.",
        "ManualReviewRequired": False,
        "StopProcessing": False,
    }
    if not result['IsFTP']:
        return result
    file_analysis = analyze_file(object_name)
    file_type = file_analysis['FileRiskType']
    risk = 'HIGH' if file_type in ('financial', 'backup', 'automated_export', 'unknown') else 'MEDIUM'
    tag = 'ftp-high-risk' if risk == 'HIGH' else 'ftp-medium-risk'
    server_note = 'Forcepoint Endpoint DLP dest is FTP client name, not FTP server. Use pcap/proxy/network logs for real server.'
    result.update(file_analysis)
    result.update({
        "RiskLevel": risk,
        "ServerNote": server_note,
        "RecommendedAction": "set_severity",
        "Severity": risk,
        "SeverityNum": risk_to_num(risk),
        "Tag": tag,
        "Reason": '{} {}'.format(file_analysis['FileReason'], server_note),
        "ManualReviewRequired": True,
    })
    return result

def main():
    args = get_args()
    outputs = check(str_arg(args.get('dest')), str_arg(args.get('category')), str_arg(args.get('object_name')))
    return_result('DLP.FTP', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
