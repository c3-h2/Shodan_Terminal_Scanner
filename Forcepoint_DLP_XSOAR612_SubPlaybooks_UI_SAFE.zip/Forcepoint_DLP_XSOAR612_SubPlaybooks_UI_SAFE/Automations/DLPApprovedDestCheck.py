# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

APPROVED_DEST_WHITELIST = [
    {"entry": "transfer.kkb.com.tr", "category": "internal_transfer", "confidence": "HIGH"},
    {"entry": "j2.kkb.com.tr", "category": "internal_system", "confidence": "HIGH"},
    {"entry": "brainchat.kkb.com.tr", "category": "internal_system", "confidence": "HIGH"},
    {"entry": "z.clarity.ms", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "clarity.ms", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "trc.taboola.com", "category": "web_tracker", "confidence": "HIGH"},
    {"entry": "google-ohttp-relay-safebrowsing.fastly-edge.com", "category": "browser_security", "confidence": "HIGH"},
    {"entry": "safebrowsing.fastly-edge.com", "category": "browser_security", "confidence": "HIGH"},
    {"entry": "dlptest.endpointprotector.com", "category": "dlp_test_tool", "confidence": "HIGH"},
    {"entry": "www.ecurep.ibm.com", "category": "it_support_portal", "confidence": "MEDIUM"},
    {"entry": "ecurep.ibm.com", "category": "it_support_portal", "confidence": "MEDIUM"},
]

def normalize_approved(entries):
    normalized = []
    for item in entries or []:
        if isinstance(item, dict):
            entry = str_arg(item.get('entry'))
            category = str_arg(item.get('category'), 'approved_destination')
            confidence = str_arg(item.get('confidence'), 'HIGH').upper()
        elif isinstance(item, (list, tuple)) and len(item) >= 3:
            entry, category, confidence = str_arg(item[0]), str_arg(item[1]), str_arg(item[2]).upper()
        else:
            entry, category, confidence = str_arg(item), 'approved_destination', 'HIGH'
        if entry:
            normalized.append({'entry': entry, 'category': category, 'confidence': confidence})
    return normalized

def check(dest, entries):
    result = {
        "InScope": True,
        "IsFP": False,
        "Confidence": "NONE",
        "Matched": None,
        "Category": None,
        "RecommendedAction": "none",
        "Severity": None,
        "SeverityNum": None,
        "Tag": None,
        "CloseReason": None,
        "CloseNotes": None,
        "Reason": "No approved destination matched.",
        "ManualReviewRequired": False,
        "StopProcessing": False,
    }
    for item in normalize_approved(entries):
        if contains_ci(dest, item['entry']):
            if item['confidence'] == 'HIGH':
                result.update({
                    "IsFP": True, "Confidence": "HIGH", "Matched": item['entry'], "Category": item['category'],
                    "RecommendedAction": "auto_close", "Severity": "LOW", "SeverityNum": 1, "Tag": "fp-approved-dest",
                    "CloseReason": "False Positive", "CloseNotes": "Approved destination: {} / {}".format(item['entry'], item['category']),
                    "Reason": "Approved high-confidence destination matched.", "ManualReviewRequired": False, "StopProcessing": True,
                })
            else:
                result.update({
                    "IsFP": True, "Confidence": item['confidence'], "Matched": item['entry'], "Category": item['category'],
                    "RecommendedAction": "set_severity", "Severity": "LOW", "SeverityNum": 1, "Tag": "low-priority-approved-dest",
                    "Reason": "Medium-confidence approved destination; analyst validation retained.", "ManualReviewRequired": True,
                })
            return result
    return result

def main():
    args = get_args()
    entries = parse_json_arg(args.get('approved_destinations_json'), APPROVED_DEST_WHITELIST)
    outputs = check(str_arg(args.get('dest')), entries)
    return_result('DLP.ApprovedDest', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
