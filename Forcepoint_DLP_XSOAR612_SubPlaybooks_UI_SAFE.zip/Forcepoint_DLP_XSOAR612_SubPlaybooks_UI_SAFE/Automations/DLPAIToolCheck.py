# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

AI_TOOLS = [
    {"domain": "claude.ai", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.anthropic.com", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chat.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chatgpt.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "gemini.google.com", "name": "Gemini", "vendor": "Google"},
    {"domain": "copilot.microsoft.com", "name": "Copilot", "vendor": "Microsoft"},
]
HIGH_RISK_KEYWORDS = ["credit card", "turkey protection of personal data", "kvkk", "db fingerprint", "yonetici onay", "yönetici onay", "mali isler", "mali işler", "musteri bilgisi", "müşteri bilgisi", "ftkw", "tckn", "iban"]
MEDIUM_RISK_KEYWORDS = ["bulk data remover", "boldon james", "fingerprint"]
LOW_RISK_KEYWORDS = ["sifreli dosya", "şifreli dosya", "7zip encrypted", "video upload blocking", "test ai"]

def match_ai_tool(dest, tools):
    for tool in tools:
        if contains_ci(dest, tool.get('domain', '')):
            return tool
    return None

def keyword_match(rules, keywords):
    for rule in rules:
        for kw in keywords:
            if kw.lower() in rule:
                return kw
    return None

def check(dest, category, tools):
    rules = split_rules(category)
    matched = match_ai_tool(dest, tools)
    result = {
        "InScope": True,
        "IsAITool": False,
        "RiskLevel": None,
        "ToolName": None,
        "Vendor": None,
        "Matched": None,
        "RulesParsed": rules,
        "RecommendedAction": "none",
        "Severity": None,
        "SeverityNum": None,
        "Tag": None,
        "Reason": "Not AI destination.",
        "ManualReviewRequired": False,
        "StopProcessing": False,
    }
    if not matched:
        return result
    risk, tag, reason = "MEDIUM", "ai-tool-medium-risk", "Unknown AI rule; conservative medium risk."
    high_kw = keyword_match(rules, HIGH_RISK_KEYWORDS)
    low_kw = keyword_match(rules, LOW_RISK_KEYWORDS)
    med_kw = keyword_match(rules, MEDIUM_RISK_KEYWORDS)
    if high_kw:
        risk, tag, reason = "HIGH", "ai-tool-high-risk", "High-risk AI rule keyword: {}".format(high_kw)
    elif low_kw:
        risk, tag, reason = "LOW", "ai-tool-fp-candidate", "Low-risk/test AI rule keyword: {}".format(low_kw)
    elif med_kw:
        risk, tag, reason = "MEDIUM", "ai-tool-medium-risk", "Medium-risk AI rule keyword: {}".format(med_kw)
    result.update({
        "IsAITool": True,
        "RiskLevel": risk,
        "ToolName": matched.get('name'),
        "Vendor": matched.get('vendor'),
        "Matched": matched.get('domain'),
        "RecommendedAction": "set_severity",
        "Severity": risk,
        "SeverityNum": risk_to_num(risk),
        "Tag": tag,
        "Reason": reason,
        "ManualReviewRequired": True,
    })
    return result

def main():
    args = get_args()
    tools = parse_json_arg(args.get('ai_tools_json'), AI_TOOLS)
    outputs = check(str_arg(args.get('dest')), str_arg(args.get('category')), tools)
    return_result('DLP.AITool', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
