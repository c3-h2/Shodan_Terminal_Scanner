# Generated for Cortex XSOAR 6.12+ Python 3 automations.
# UI-safe: create a new Python 3 automation and paste this file content.
import json
import re
import ipaddress

try:
    from CommonServerPython import *  # type: ignore
except Exception:
    pass

SEVERITY_NAME_TO_NUM = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

def str_arg(value, default=""):
    if value is None:
        return default
    return str(value)

def bool_arg(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "yes", "y", "1", "on")

def normalize(value):
    return str_arg(value).strip().lower()

def contains_ci(haystack, needle):
    h = normalize(haystack)
    n = normalize(needle)
    return bool(n) and n in h

def contains_any_ci(haystack, needles):
    h = normalize(haystack)
    return any(str(n).lower() in h for n in needles if n)

def split_rules(category):
    raw = str_arg(category)
    return [r.strip().lower() for r in raw.split(';') if r.strip()]

def parse_json_arg(value, default):
    if value in (None, "", "null"):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default

def parse_csv(value):
    if value in (None, ""):
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(',') if x.strip()]

def extract_ips(value):
    text = str_arg(value)
    return re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)

def is_private_rfc1918(ip_text):
    try:
        ip = ipaddress.ip_address(ip_text)
        return ip.version == 4 and ip.is_private
    except Exception:
        return False

def is_loopback_ip(ip_text):
    try:
        return ipaddress.ip_address(ip_text).is_loopback
    except Exception:
        return False

def risk_to_num(risk_level):
    return SEVERITY_NAME_TO_NUM.get(str(risk_level).upper(), 2)

def get_args():
    try:
        return demisto.args()  # type: ignore[name-defined]
    except Exception:
        return {}

def return_result(prefix, outputs, readable=None):
    try:
        if readable is None:
            readable = tableToMarkdown(prefix, outputs, removeNull=True)  # type: ignore[name-defined]
        return_results(CommandResults(outputs_prefix=prefix, outputs=outputs, readable_output=readable))  # type: ignore[name-defined]
    except Exception:
        print(json.dumps({prefix: outputs}, indent=2, ensure_ascii=False))

AI_TOOLS = [
    {"domain": "claude.ai", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.anthropic.com", "name": "Claude", "vendor": "Anthropic"},
    {"domain": "api.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chat.openai.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "chatgpt.com", "name": "ChatGPT", "vendor": "OpenAI"},
    {"domain": "gemini.google.com", "name": "Gemini", "vendor": "Google"},
    {"domain": "copilot.microsoft.com", "name": "Copilot", "vendor": "Microsoft"},
]

def match_ai_tool(dest, tools):
    for tool in tools:
        if contains_ci(dest, tool.get('domain', '')):
            return tool
    return None

def detect_subtype(category):
    c = normalize(category)
    if 'test' in c:
        return 'test'
    if 'yonetici onay' in c or 'yönetici onay' in c:
        return 'yonetici_onay'
    if 'db fingerprint' in c:
        return 'db_fingerprint'
    if 'turkey' in c or 'kvkk' in c or 'kvk' in c:
        return 'turkey_pd'
    if 'musteri bilgisi' in c or 'müşteri bilgisi' in c:
        return 'musteri_bilgisi'
    if 'bulk data' in c:
        return 'bulk_data'
    if 'fingerprint' in c:
        return 'fingerprint'
    return 'standard'

def classify_dest(dest):
    d = normalize(dest)
    if contains_any_ci(d, ['gmail', 'hotmail', 'icloud', 'windowslive', 'outlook.com', 'live.com', 'yandex']):
        return 'personal_email'
    if 'riskmerkezi' in d:
        return 'authorized_partner'
    if '@kkb.com.tr' in d or '.kkb.com.tr' in d or d.endswith('kkb.com.tr'):
        return 'internal'
    if d in ('smtp', 'endpoint https') or 'endpoint https' in d:
        return 'generic_channel'
    return 'corporate_external'

def check(dest, category, skip_if_ai_tool, ai_tools):
    is_bj = contains_ci(category, 'Boldon James')
    result = {
        "InScope": is_bj,
        "IsBJ": is_bj,
        "Skipped": False,
        "SkipReason": None,
        "RiskLevel": None,
        "DestType": None,
        "RuleSubtype": None,
        "RecommendedAction": "none",
        "Severity": None,
        "SeverityNum": None,
        "Tag": None,
        "Reason": "Not a Boldon James rule." if not is_bj else "No decision generated.",
        "ManualReviewRequired": False,
        "StopProcessing": False,
    }
    if not is_bj:
        return result
    if skip_if_ai_tool and match_ai_tool(dest, ai_tools):
        result.update({"Skipped": True, "SkipReason": "Skipped because AI destination matched; AI Triage is authoritative.", "Reason": "Skipped due to AI destination."})
        return result
    subtype = detect_subtype(category)
    dest_type = classify_dest(dest)
    if subtype == 'test':
        risk, tag, reason = 'LOW', 'bj-fp-candidate', 'Boldon James test subtype.'
    elif dest_type == 'personal_email':
        risk, tag, reason = 'HIGH', 'bj-high-risk', 'Personal email destination.'
    elif subtype in ('yonetici_onay', 'db_fingerprint', 'turkey_pd', 'musteri_bilgisi'):
        risk, tag, reason = 'HIGH', 'bj-high-risk', 'Sensitive Boldon James subtype.'
    elif dest_type == 'authorized_partner':
        if subtype in ('fingerprint', 'bulk_data'):
            risk, tag, reason = 'MEDIUM', 'bj-medium-risk', 'Authorized partner with fingerprint/bulk subtype.'
        else:
            risk, tag, reason = 'LOW', 'bj-fp-candidate', 'Authorized partner with standard subtype.'
    elif dest_type == 'internal':
        risk, tag, reason = 'LOW', 'bj-fp-candidate', 'Internal destination.'
    else:
        risk, tag, reason = 'MEDIUM', 'bj-medium-risk', 'External/generic destination with non-critical subtype.'
    result.update({
        "RiskLevel": risk, "DestType": dest_type, "RuleSubtype": subtype,
        "RecommendedAction": "set_severity", "Severity": risk, "SeverityNum": risk_to_num(risk),
        "Tag": tag, "Reason": reason, "ManualReviewRequired": True,
    })
    return result

def main():
    args = get_args()
    skip_if_ai_tool = bool_arg(args.get('skip_if_ai_tool'), True)
    ai_tools = parse_json_arg(args.get('ai_tools_json'), AI_TOOLS)
    outputs = check(str_arg(args.get('dest')), str_arg(args.get('category')), skip_if_ai_tool, ai_tools)
    return_result('DLP.BoldonJames', outputs)

if __name__ in ('__main__', '__builtin__', 'builtins'):
    main()
