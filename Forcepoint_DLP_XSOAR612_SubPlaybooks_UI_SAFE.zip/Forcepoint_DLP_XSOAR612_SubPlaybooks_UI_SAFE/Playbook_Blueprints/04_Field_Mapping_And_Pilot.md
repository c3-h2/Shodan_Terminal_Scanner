# 04 — Field Mapping and Pilot Plan

## Forcepoint DLP 10.2 alan doğrulaması

Pseudo kod aşağıdaki incident field modelini kullanıyor:

| Pseudo field | Anlam |
|---|---|
| `incident.dest` | HTTPS/Web için domain/IP; FTP için çoğu zaman FTP client adı |
| `incident.category` | DLP kural adı; birden fazla kural `;` ile gelebilir |
| `incident.app` | Uygulama / endpoint application |
| `incident.object` | Dosya adı/yolu ve bazen boyut bilgisi |
| `incident.severity` | XSOAR severity |

XSOAR mapper'ında alan adları farklıysa master playbook input'larını buna göre değiştir:

```text
dest=${incident.<senin_dest_field>}
category=${incident.<senin_rule_field>}
app=${incident.<senin_app_field>}
object_name=${incident.<senin_object_field>}
```

## İlk pilot ayarı

Master playbook input default'ları:

```text
dry_run=false
update_incident=true
close_incident=false
never_lower_severity=true
```

Bu modda:

- Incident severity ve DLP triage label'ları güncellenir.
- Auto-close adayı üretilir ama incident kapatılmaz.
- `dlp_triage_tag`, `dlp_triage_action`, `dlp_triage_reason`, `dlp_triage_matched` label'ları eklenir.

## Auto-close açma kriteri

`close_incident=true` sadece şu üç high-confidence FP case'i doğrulandıktan sonra açılmalı:

1. GitHub Copilot + Software Source Code FP
2. Localhost / loopback / onaylı internal development server FP
3. Approved Destination HIGH FP

FTP, AI Tool ve Boldon James case'leri hiçbir durumda otomatik kapanmaz.
