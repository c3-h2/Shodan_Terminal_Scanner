# 01 — Automation Argument Definitions

## Ortak checker inputları

Bu checker automation'lar incident üzerinde doğrudan değişiklik yapmaz. Sadece context output üretir.

### DLPFPDestCheck

| Argüman | Zorunlu | Örnek |
|---|---:|---|
| `dest` | Evet | `${incident.dest}` |
| `category` | Evet | `${incident.category}` |
| `copilot_whitelist_json` | Hayır | JSON liste |

Output prefix: `DLP.GitHubCopilot`

### DLPLocalDestCheck

| Argüman | Zorunlu | Örnek |
|---|---:|---|
| `dest` | Evet | `${incident.dest}` |
| `category` | Evet | `${incident.category}` |
| `internal_dev_servers` | Hayır | `10.200.107.112,10.200.115.23` |

Output prefix: `DLP.LocalDest`

### DLPApprovedDestCheck

| Argüman | Zorunlu | Örnek |
|---|---:|---|
| `dest` | Evet | `${incident.dest}` |
| `approved_destinations_json` | Hayır | JSON liste |

Output prefix: `DLP.ApprovedDest`

### DLPAIToolCheck

| Argüman | Zorunlu | Örnek |
|---|---:|---|
| `dest` | Evet | `${incident.dest}` |
| `category` | Evet | `${incident.category}` |
| `ai_tools_json` | Hayır | JSON liste |

Output prefix: `DLP.AITool`

### DLPBoldonJamesCheck

| Argüman | Zorunlu | Örnek |
|---|---:|---|
| `dest` | Evet | `${incident.dest}` |
| `category` | Evet | `${incident.category}` |
| `skip_if_ai_tool` | Hayır | `true` |
| `ai_tools_json` | Hayır | JSON liste |

Output prefix: `DLP.BoldonJames`

### DLPFTPCheck

| Argüman | Zorunlu | Örnek |
|---|---:|---|
| `dest` | Evet | `${incident.dest}` |
| `category` | Evet | `${incident.category}` |
| `object_name` | Evet | `${incident.object}` |

Output prefix: `DLP.FTP`

## DLPApplyTriageDecision

Bu automation merkezi uygulama katmanıdır. Severity, label ve close işlemi burada yapılır.

| Argüman | Zorunlu | Açıklama |
|---|---:|---|
| `action` | Evet | `none`, `set_severity`, `auto_close` |
| `severity` | Hayır | `LOW`, `MEDIUM`, `HIGH`, `CRITICAL` |
| `severity_num` | Hayır | XSOAR numeric severity: 1/2/3/4 |
| `tag` | Hayır | `fp-github-copilot`, `ftp-high-risk` vb. |
| `reason` | Hayır | Karar açıklaması |
| `matched` | Hayır | Eşleşen domain/IP/risk tipi |
| `close_reason` | Hayır | Default: `False Positive` |
| `close_notes` | Hayır | Close notu |
| `dry_run` | Hayır | `true/false` |
| `update_incident` | Hayır | `true/false` |
| `close_incident` | Hayır | `true/false` |
| `never_lower_severity` | Hayır | Default `true` |

Output prefix: `DLP.Triage.Applied`

Önemli: İlk pilotta `close_incident=false` kalmalı.
