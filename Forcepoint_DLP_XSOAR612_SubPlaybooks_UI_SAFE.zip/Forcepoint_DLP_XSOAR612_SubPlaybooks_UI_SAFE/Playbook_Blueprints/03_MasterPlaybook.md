# 03 — Master Playbook Blueprint

Master playbook adı:

```text
DLP_Master_Triage
```

Amaç: Pseudo koddaki sabit sıralamayı XSOAR sub-playbook orchestration olarak kurmak.

## Master inputs

| Input | Default / örnek |
|---|---|
| `dest` | `${incident.dest}` |
| `category` | `${incident.category}` |
| `app` | `${incident.app}` |
| `object_name` | `${incident.object}` |
| `dry_run` | `false` |
| `update_incident` | `true` |
| `close_incident` | `false` |
| `never_lower_severity` | `true` |

## Master task akışı

### 1. Start

Start task.

### 2. Call Sub-PB 1 — GitHub Copilot

Playbook task:

```text
DLP_GithubCopilot_Autoclose
```

Inputs:

```text
dest=${inputs.dest}
category=${inputs.category}
app=${inputs.app}
object_name=${inputs.object_name}
dry_run=${inputs.dry_run}
update_incident=${inputs.update_incident}
close_incident=${inputs.close_incident}
never_lower_severity=${inputs.never_lower_severity}
```

### 3. Condition — Stop after auto-close candidate?

Condition:

```text
DLP.Triage.Applied.StopProcessing equals true
```

- `true` → End
- `false / not exists` → Task 4

Bu adım pseudo kodda `closeInvestigation` sonrası diğer sub-playbook'ların pratikte değişiklik yapamaması davranışının XSOAR karşılığıdır. Pilot modda `close_incident=false` olsa bile high-confidence FP kararının sonraki triage task'ları tarafından ezilmesini önler.

### 4. Call Sub-PB 2 — Localhost/Internal

Playbook task:

```text
DLP_Localhost_Autoclose
```

Aynı inputs ile çağır.

### 5. Condition — Stop after auto-close candidate?

```text
DLP.Triage.Applied.StopProcessing equals true
```

- `true` → End
- `false / not exists` → Task 6

### 6. Call Sub-PB 3 — Approved Destination

Playbook task:

```text
DLP_ApprovedDest_Autoclose
```

Aynı inputs ile çağır.

### 7. Condition — Stop after auto-close candidate?

```text
DLP.Triage.Applied.StopProcessing equals true
```

- `true` → End
- `false / not exists` → Task 8

### 8. Call Sub-PB 4 — AI Tool Triage

Playbook task:

```text
DLP_AITool_Triage
```

Aynı inputs ile çağır.

### 9. Call Sub-PB 5 — Boldon James Triage

Playbook task:

```text
DLP_BoldonJames_Triage
```

Aynı inputs ile çağır.

### 10. Call Sub-PB 6 — FTP Action Triage

Playbook task:

```text
DLP_FTPAction_Triage
```

Aynı inputs ile çağır.

### 11. Condition — Any decision applied?

Condition:

```text
DLP.Triage.Applied.Processed exists
```

- Exists / true → End
- Not exists / false → Task 12

### 12. Default Manual Triage

Automation task:

```text
DLPApplyTriageDecision
```

Args:

```text
action=set_severity
severity=MEDIUM
severity_num=2
tag=manual-triage-required
reason=No DLP triage scope matched; routed to analyst queue.
dry_run=${inputs.dry_run}
update_incident=${inputs.update_incident}
close_incident=false
never_lower_severity=${inputs.never_lower_severity}
```

### 13. End

End task.

## Nihai sıra

```text
Start
  → DLP_GithubCopilot_Autoclose
  → stop? else
  → DLP_Localhost_Autoclose
  → stop? else
  → DLP_ApprovedDest_Autoclose
  → stop? else
  → DLP_AITool_Triage
  → DLP_BoldonJames_Triage
  → DLP_FTPAction_Triage
  → decision exists?
      yes → End
      no  → Default Manual Triage → End
```

## Neden stop condition var?

Pseudo kodda GitHub Copilot, Localhost ve Approved Destination HIGH case'leri alarmı kapatıyor. XSOAR pilotunda `close_incident=false` çalıştırıldığında alarm kapanmayacağı için sonraki sub-playbook'lar aynı incident üzerinde yeni severity/tag basabilir. Bu nedenle master playbook'ta `StopProcessing=true` kontrolü eklendi. Prod'da `close_incident=true` olduğunda da bu davranış güvenlidir.
