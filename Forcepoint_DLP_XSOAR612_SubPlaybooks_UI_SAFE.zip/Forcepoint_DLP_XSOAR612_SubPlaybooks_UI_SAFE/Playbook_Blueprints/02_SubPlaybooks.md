# 02 — Sub-Playbook Blueprint'leri

Aşağıdaki 6 sub-playbook'u XSOAR UI üzerinden manuel oluştur. Her sub-playbook için inputlar ortak tutulur.

## Ortak sub-playbook inputs

Her sub-playbook'a şu inputları ekle:

| Input | Örnek default |
|---|---|
| `dest` | `${incident.dest}` |
| `category` | `${incident.category}` |
| `app` | `${incident.app}` |
| `object_name` | `${incident.object}` |
| `dry_run` | `false` |
| `update_incident` | `true` |
| `close_incident` | `false` |
| `never_lower_severity` | `true` |

> İlk pilotta `close_incident=false`. Production auto-close onayından sonra sadece HIGH-confidence FP case'leri için master input üzerinden `true` yapılmalı.

---

## 1. DLP_GithubCopilot_Autoclose

Pseudo kod karşılığı: `SUB-PLAYBOOK 1: DLP_GithubCopilot_Autoclose`

### Task akışı

1. **Start**
2. **Check GitHub Copilot FP**
   - Automation: `DLPFPDestCheck`
   - Args:
     - `dest=${inputs.dest}`
     - `category=${inputs.category}`
3. **Condition: Is action required?**
   - If `DLP.GitHubCopilot.RecommendedAction` equals `auto_close` → Task 4
   - If `DLP.GitHubCopilot.RecommendedAction` equals `set_severity` → Task 4
   - Else → End
4. **Apply GitHub Copilot Decision**
   - Automation: `DLPApplyTriageDecision`
   - Args:
     - `action=${DLP.GitHubCopilot.RecommendedAction}`
     - `severity=${DLP.GitHubCopilot.Severity}`
     - `severity_num=${DLP.GitHubCopilot.SeverityNum}`
     - `tag=${DLP.GitHubCopilot.Tag}`
     - `reason=${DLP.GitHubCopilot.Reason}`
     - `matched=${DLP.GitHubCopilot.Matched}`
     - `close_reason=${DLP.GitHubCopilot.CloseReason}`
     - `close_notes=${DLP.GitHubCopilot.CloseNotes}`
     - `dry_run=${inputs.dry_run}`
     - `update_incident=${inputs.update_incident}`
     - `close_incident=${inputs.close_incident}`
     - `never_lower_severity=${inputs.never_lower_severity}`
5. **End**

---

## 2. DLP_Localhost_Autoclose

Pseudo kod karşılığı: `SUB-PLAYBOOK 2: DLP_Localhost_Autoclose`

### Task akışı

1. **Start**
2. **Check Local/Internal Destination**
   - Automation: `DLPLocalDestCheck`
   - Args:
     - `dest=${inputs.dest}`
     - `category=${inputs.category}`
     - `internal_dev_servers=10.200.107.112,10.200.115.23`
3. **Condition: Is action required?**
   - If `DLP.LocalDest.RecommendedAction` equals `auto_close` → Task 4
   - If `DLP.LocalDest.RecommendedAction` equals `set_severity` → Task 4
   - Else → End
4. **Apply Local/Internal Decision**
   - Automation: `DLPApplyTriageDecision`
   - Args:
     - `action=${DLP.LocalDest.RecommendedAction}`
     - `severity=${DLP.LocalDest.Severity}`
     - `severity_num=${DLP.LocalDest.SeverityNum}`
     - `tag=${DLP.LocalDest.Tag}`
     - `reason=${DLP.LocalDest.Reason}`
     - `matched=${DLP.LocalDest.Matched}`
     - `close_reason=${DLP.LocalDest.CloseReason}`
     - `close_notes=${DLP.LocalDest.CloseNotes}`
     - `dry_run=${inputs.dry_run}`
     - `update_incident=${inputs.update_incident}`
     - `close_incident=${inputs.close_incident}`
     - `never_lower_severity=${inputs.never_lower_severity}`
5. **End**

---

## 3. DLP_ApprovedDest_Autoclose

Pseudo kod karşılığı: `SUB-PLAYBOOK 3: DLP_ApprovedDest_Autoclose`

### Task akışı

1. **Start**
2. **Check Approved Destination**
   - Automation: `DLPApprovedDestCheck`
   - Args:
     - `dest=${inputs.dest}`
3. **Condition: Is action required?**
   - If `DLP.ApprovedDest.RecommendedAction` equals `auto_close` → Task 4
   - If `DLP.ApprovedDest.RecommendedAction` equals `set_severity` → Task 4
   - Else → End
4. **Apply Approved Destination Decision**
   - Automation: `DLPApplyTriageDecision`
   - Args:
     - `action=${DLP.ApprovedDest.RecommendedAction}`
     - `severity=${DLP.ApprovedDest.Severity}`
     - `severity_num=${DLP.ApprovedDest.SeverityNum}`
     - `tag=${DLP.ApprovedDest.Tag}`
     - `reason=${DLP.ApprovedDest.Reason}`
     - `matched=${DLP.ApprovedDest.Matched}`
     - `close_reason=${DLP.ApprovedDest.CloseReason}`
     - `close_notes=${DLP.ApprovedDest.CloseNotes}`
     - `dry_run=${inputs.dry_run}`
     - `update_incident=${inputs.update_incident}`
     - `close_incident=${inputs.close_incident}`
     - `never_lower_severity=${inputs.never_lower_severity}`
5. **End**

---

## 4. DLP_AITool_Triage

Pseudo kod karşılığı: `SUB-PLAYBOOK 4: DLP_AITool_Triage`

### Task akışı

1. **Start**
2. **Check AI Tool**
   - Automation: `DLPAIToolCheck`
   - Args:
     - `dest=${inputs.dest}`
     - `category=${inputs.category}`
3. **Condition: Is AI tool?**
   - If `DLP.AITool.IsAITool` equals `true` → Task 4
   - Else → End
4. **Apply AI Tool Decision**
   - Automation: `DLPApplyTriageDecision`
   - Args:
     - `action=${DLP.AITool.RecommendedAction}`
     - `severity=${DLP.AITool.Severity}`
     - `severity_num=${DLP.AITool.SeverityNum}`
     - `tag=${DLP.AITool.Tag}`
     - `reason=${DLP.AITool.Reason}`
     - `matched=${DLP.AITool.Matched}`
     - `dry_run=${inputs.dry_run}`
     - `update_incident=${inputs.update_incident}`
     - `close_incident=false`
     - `never_lower_severity=${inputs.never_lower_severity}`
5. **End**

Not: AI Tool triage hiçbir durumda auto-close yapmaz.

---

## 5. DLP_BoldonJames_Triage

Pseudo kod karşılığı: `SUB-PLAYBOOK 5: DLP_BoldonJames_Triage`

### Task akışı

1. **Start**
2. **Check Boldon James**
   - Automation: `DLPBoldonJamesCheck`
   - Args:
     - `dest=${inputs.dest}`
     - `category=${inputs.category}`
     - `skip_if_ai_tool=true`
3. **Condition: Is BJ action required?**
   - If `DLP.BoldonJames.RecommendedAction` equals `set_severity` → Task 4
   - Else → End
4. **Apply Boldon James Decision**
   - Automation: `DLPApplyTriageDecision`
   - Args:
     - `action=${DLP.BoldonJames.RecommendedAction}`
     - `severity=${DLP.BoldonJames.Severity}`
     - `severity_num=${DLP.BoldonJames.SeverityNum}`
     - `tag=${DLP.BoldonJames.Tag}`
     - `reason=${DLP.BoldonJames.Reason}`
     - `matched=${DLP.BoldonJames.DestType}`
     - `dry_run=${inputs.dry_run}`
     - `update_incident=${inputs.update_incident}`
     - `close_incident=false`
     - `never_lower_severity=${inputs.never_lower_severity}`
5. **End**

Not: AI destination tespit edilirse bu sub-playbook kendini skip eder.

---

## 6. DLP_FTPAction_Triage

Pseudo kod karşılığı: `SUB-PLAYBOOK 6: DLP_FTPAction_Triage`

### Task akışı

1. **Start**
2. **Check FTP Action**
   - Automation: `DLPFTPCheck`
   - Args:
     - `dest=${inputs.dest}`
     - `category=${inputs.category}`
     - `object_name=${inputs.object_name}`
3. **Condition: Is FTP?**
   - If `DLP.FTP.IsFTP` equals `true` → Task 4
   - Else → End
4. **Apply FTP Decision**
   - Automation: `DLPApplyTriageDecision`
   - Args:
     - `action=${DLP.FTP.RecommendedAction}`
     - `severity=${DLP.FTP.Severity}`
     - `severity_num=${DLP.FTP.SeverityNum}`
     - `tag=${DLP.FTP.Tag}`
     - `reason=${DLP.FTP.Reason}`
     - `matched=${DLP.FTP.FileRiskType}`
     - `dry_run=${inputs.dry_run}`
     - `update_incident=${inputs.update_incident}`
     - `close_incident=false`
     - `never_lower_severity=${inputs.never_lower_severity}`
5. **End**

Not: FTP hiçbir durumda auto-close yapmaz. Forcepoint Endpoint DLP'de `dest` FTP server değil, FTP client adıdır.
