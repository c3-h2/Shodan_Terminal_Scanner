# Forcepoint DLP Triage — XSOAR 6.12 Sub-Playbook Package

Bu paket, ilk pseudo koddaki tasarımı tek master automation yerine gerçek XSOAR orkestrasyonuna böler:

- Her case ayrı sub-playbook olarak çalışır.
- Master playbook sub-playbook'ları sabit sırayla çağırır.
- Checker automation'lar sadece karar üretir.
- `DLPApplyTriageDecision` automation'ı incident update / severity / label / close işlemini merkezi yapar.
- FTP, AI Tool ve Boldon James triage case'leri otomatik kapatma yapmaz.
- GitHub Copilot, Localhost/Internal Dev ve Approved Destination HIGH case'leri auto-close adayı üretir.

## Neden YAML yok?

Senin XSOAR ortamında bazı YAML import'larında `msgpack: invalid code=c3 decoding string/bytes length` ve format hataları oluştuğu için bu paket UI-safe üretildi. Yani bu dosyalar XSOAR'a content pack olarak import edilmez. Python dosyaları Automation ekranında elle oluşturulur, playbook/sub-playbook'lar UI üzerinden blueprint'e göre kurulur.

## Kurulum sırası

1. `Automations/` altındaki 7 Python dosyasını XSOAR'da Python 3 automation olarak oluştur.
2. Önce `DLPApplyTriageDecision` automation'ını oluştur.
3. Sonra 6 checker automation'ı oluştur.
4. `Playbook_Blueprints/02_SubPlaybooks.md` dosyasına göre 6 sub-playbook oluştur.
5. `Playbook_Blueprints/03_MasterPlaybook.md` dosyasına göre master playbook oluştur.
6. Forcepoint DLP incident type'a master playbook'u bağla.
7. İlk pilotta `close_incident=false` kullan.

## Dosya listesi

- `Automations/DLPFPDestCheck.py`
- `Automations/DLPLocalDestCheck.py`
- `Automations/DLPApprovedDestCheck.py`
- `Automations/DLPAIToolCheck.py`
- `Automations/DLPBoldonJamesCheck.py`
- `Automations/DLPFTPCheck.py`
- `Automations/DLPApplyTriageDecision.py`
- `Playbook_Blueprints/01_Automation_Arguments.md`
- `Playbook_Blueprints/02_SubPlaybooks.md`
- `Playbook_Blueprints/03_MasterPlaybook.md`
- `Playbook_Blueprints/04_Field_Mapping_And_Pilot.md`
- `Tests/test_commands.md`
