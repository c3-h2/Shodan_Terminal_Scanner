# Test Commands

Automation'ları oluşturduktan sonra War Room'da tek tek test et.

## GitHub Copilot FP

```text
!DLPFPDestCheck dest="proxy.business.githubcopilot.com" category="Software Source Code"
```

Beklenen:

```text
RecommendedAction=auto_close
Tag=fp-github-copilot
StopProcessing=true
```

## Localhost FP

```text
!DLPLocalDestCheck dest="127.0.0.1" category="Boldon James - Test"
```

Beklenen:

```text
RecommendedAction=auto_close
Tag=fp-localhost
StopProcessing=true
```

## Approved Destination MEDIUM

```text
!DLPApprovedDestCheck dest="www.ecurep.ibm.com"
```

Beklenen:

```text
RecommendedAction=set_severity
Severity=LOW
Tag=low-priority-approved-dest
```

## AI Tool HIGH

```text
!DLPAIToolCheck dest="chatgpt.com" category="KVKK; Credit Card"
```

Beklenen:

```text
IsAITool=true
RecommendedAction=set_severity
Severity=HIGH
Tag=ai-tool-high-risk
```

## Boldon James personal email HIGH

```text
!DLPBoldonJamesCheck dest="user@gmail.com" category="Boldon James - Standard"
```

Beklenen:

```text
RecommendedAction=set_severity
Severity=HIGH
Tag=bj-high-risk
```

## FTP backup HIGH

```text
!DLPFTPCheck dest="FileZilla FTP Client" category="FTP ACTIONS" object_name="backup_full.zip - 20 MB"
```

Beklenen:

```text
IsFTP=true
Severity=HIGH
Tag=ftp-high-risk
```

## Apply decision dry-run

```text
!DLPApplyTriageDecision action=set_severity severity=HIGH severity_num=3 tag="test-tag" reason="dry run validation" dry_run=true update_incident=true close_incident=false
```

Beklenen: Incident değişmez, context output oluşur.
