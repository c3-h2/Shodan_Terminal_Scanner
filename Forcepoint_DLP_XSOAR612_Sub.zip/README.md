# Forcepoint DLP XSOAR 6.12 Sub-Playbooks - YAML Checked

Bu paket, ilk pseudo kodda tarif edilen case ayrımını gerçek XSOAR playbook yapısına böler:

- Her case ayrı sub-playbook'tur.
- Master playbook sub-playbook'ları sabit sırayla çağırır.
- GitHub Copilot, Localhost/Internal ve Approved Destination high-confidence FP kararlarında `StopProcessing=true` üretir.
- Pilot modda `close_incident=false` ile auto-close önerisi üretilir ancak incident kapatılmaz.
- `close_incident=true` ancak pilot doğrulama sonrası açılmalıdır.

Dosyalar `pyyaml.safe_load` ile parse edildi; automation Python dosyaları `py_compile` ile compile edildi; playbook graph referansları doğrulandı.

Detaylar için:

- `IMPORT_ORDER.md`
- `Validation/YAML_VALIDATION_REPORT.md`
