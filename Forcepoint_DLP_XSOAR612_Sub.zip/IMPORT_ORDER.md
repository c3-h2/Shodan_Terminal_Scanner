# XSOAR 6.12 Import Order - Forcepoint DLP Sub-Playbooks

Bu paket Content Pack olarak değil, tekil Automation ve Playbook YAML import'u için hazırlanmıştır.

## 1) Automation YAML import sırası

XSOAR UI: Settings / Automation Scripts / Import

1. `Automations/automation-DLPApplyTriageDecision.yml`
2. `Automations/automation-DLPFPDestCheck.yml`
3. `Automations/automation-DLPLocalDestCheck.yml`
4. `Automations/automation-DLPApprovedDestCheck.yml`
5. `Automations/automation-DLPAIToolCheck.yml`
6. `Automations/automation-DLPBoldonJamesCheck.yml`
7. `Automations/automation-DLPFTPCheck.yml`

## 2) Sub-playbook YAML import sırası

XSOAR UI: Playbooks / Import

1. `Playbooks/playbook-DLP_GithubCopilot_Autoclose.yml`
2. `Playbooks/playbook-DLP_Localhost_Autoclose.yml`
3. `Playbooks/playbook-DLP_ApprovedDest_Autoclose.yml`
4. `Playbooks/playbook-DLP_AITool_Triage.yml`
5. `Playbooks/playbook-DLP_BoldonJames_Triage.yml`
6. `Playbooks/playbook-DLP_FTPAction_Triage.yml`

## 3) Master playbook import

En son import et:

1. `Playbooks/playbook-DLP_Master_Triage.yml`

## 4) İlk pilot input ayarları

Master playbook inputs:

```text
dry_run=false
update_incident=true
close_incident=false
never_lower_severity=true

dest=<Forcepoint destination field value veya mapper ile gelen dest>
category=<Forcepoint DLP rule/category>
app=<application>
object_name=<file/object>
```

Incident Type'a bağlarken field değerlerini playbook input'a map et.

## 5) Auto-close geçişi

İlk pilotta `close_incident=false` kalmalı. FP doğruluğu kanıtlandıktan sonra sadece high-confidence FP senaryoları için master input'ta `close_incident=true` yapılır.

Auto-close üretebilen sub-playbook'lar:

- DLP_GithubCopilot_Autoclose
- DLP_Localhost_Autoclose
- DLP_ApprovedDest_Autoclose

AI, Boldon James ve FTP sub-playbook'ları auto-close üretmez; sadece severity/tag verir.
