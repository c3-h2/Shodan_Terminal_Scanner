# YAML Validation Report
Generated package: Forcepoint_DLP_XSOAR612_SubPlaybooks_YAML_CHECKED

## Checks
- Python automation compile: PASS (7 files)
- YAML parse: PASS (14 files)
- Playbook task graph validation: PASS
- Referenced automation names exist in package: PASS
- Referenced sub-playbook names exist in package: PASS

## Files checked
- `Automations/automation-DLPAIToolCheck.yml`
- `Automations/automation-DLPApplyTriageDecision.yml`
- `Automations/automation-DLPApprovedDestCheck.yml`
- `Automations/automation-DLPBoldonJamesCheck.yml`
- `Automations/automation-DLPFPDestCheck.yml`
- `Automations/automation-DLPFTPCheck.yml`
- `Automations/automation-DLPLocalDestCheck.yml`
- `Playbooks/playbook-DLP_AITool_Triage.yml`
- `Playbooks/playbook-DLP_ApprovedDest_Autoclose.yml`
- `Playbooks/playbook-DLP_BoldonJames_Triage.yml`
- `Playbooks/playbook-DLP_FTPAction_Triage.yml`
- `Playbooks/playbook-DLP_GithubCopilot_Autoclose.yml`
- `Playbooks/playbook-DLP_Localhost_Autoclose.yml`
- `Playbooks/playbook-DLP_Master_Triage.yml`

## Errors
- None
